#!/usr/bin/env python3
"""Exact polynomial-reduction checks for the stable Peabody tail chart."""
from __future__ import annotations
import json
from pathlib import Path
import sympy as sp

ROOT = Path(__file__).resolve().parent.parent
q, x, K, D, R, T = sp.symbols("q x K D R T")
relations = [
    D**2 - K**2 - q**2,
    R**2 - K**2 - q**2 + 2*K*q*x**2,
    T**2 - 2*K*(K**2 + q**2) - K**2*(1-q)**2*x**2,
]
G = sp.groebner(relations, D, R, T, x, q, K, order="grevlex")

def reduce_poly(expr: sp.Expr) -> sp.Expr:
    num = sp.together(expr).as_numer_denom()[0]
    return sp.factor(G.reduce(sp.expand(num))[1])

# Rationalization of delta=(R-K+q)/q.
delta_identity = (R-K+q)*(R+K-q) - 2*K*q*(1-x**2)

# Mbar/q stable rewrite.
Mbar = (1-q)*(K+q)*R - (1+q)*(K**2+q**2)
Mq = K*(q-2*K*x**2)/(R+K) + (1-K)*R - K**2 - q*R - q - q**2
m_identity = Mbar - q*Mq

# Stable ArcTan argument.  Original y^2 and c are used to avoid square-root branches.
y2 = 2*K*q/(K+q+D)**2
c = (1-q)*R/((1+q)*D)
z2_original = y2*(1+c)/(1-c)
z2_stable = K**2*((1+q)*D+(1-q)*R)**2/(T**2*(K+q+D)**2)
angle_identity = z2_original - z2_stable

results = {
    "delta_identity_remainder": sp.sstr(reduce_poly(delta_identity)),
    "M_identity_remainder": sp.sstr(reduce_poly(m_identity)),
    "angle_argument_squared_identity_remainder": sp.sstr(reduce_poly(angle_identity)),
}
results["pass"] = all(v == "0" for v in results.values())
results["classification"] = "PEABODY_TAIL_STABLE_CHART_EXACT_IDENTITIES_PASS" if results["pass"] else "PEABODY_TAIL_STABLE_CHART_EXACT_IDENTITIES_FAIL"
(ROOT / "data" / "tail_chart_exact_identity_audit.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
print(json.dumps(results, indent=2))
