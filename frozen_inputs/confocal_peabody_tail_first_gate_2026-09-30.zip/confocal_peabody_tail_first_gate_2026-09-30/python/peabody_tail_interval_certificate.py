#!/usr/bin/env python3
"""Outward-rounded tail certificate for confocal Peabody Phi(e) > 0.

Proof target
------------
For q=(1-e)/(1+e) and 0 <= q <= 1/399, certify

    Phi((1-q)/(1+q)) = (Psi(q)-Psi(0))/8 > 0.

This proves Phi(e)>0 for 199/200 <= e < 1.  The endpoint q=0 is the
continuous parabolic limit and is included only to close the compact interval.

The proof uses a stable q-chart for the already validated fixed-interval
integrand H(q,x), x in [0,1], and a direct interval Riemann enclosure.  It does
not attempt to prove Phi'(e)>0, which is sufficient but unnecessary.

Trust boundary
--------------
* Python integer/rational control flow and CSV/JSON serialization;
* mpmath 1.3.0 MP interval arithmetic at the requested decimal precision;
* elementary interval operations +, -, *, /, sqrt, and atan2 on domains
  separately certified to avoid zero denominators and branch crossings.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import mpmath as mp
from mpmath.libmp import to_str

FORMULA_VERSION = "PEABODY_TAIL_STABLE_Q_V1"
DEFAULT_PRECISION = 80
DEFAULT_Q_SLABS = 5
DEFAULT_X_PANELS = 400
Q_MAX_DENOMINATOR = 399
SIMPLE_RATIONAL_TARGET_NUMERATOR = 1
SIMPLE_RATIONAL_TARGET_DENOMINATOR = 20000
MAX_TERMINAL_BOXES = 5000
MAX_CERTIFICATE_BYTES = 10_000_000


@dataclass(frozen=True)
class IntervalConstants:
    iv: object
    one: object
    sqrt2: object
    kappa: object
    K: object
    psi0: object


def _setup(precision_dps: int) -> IntervalConstants:
    if precision_dps < 40:
        raise ValueError("precision_dps must be at least 40")
    mp.iv.dps = precision_dps
    iv = mp.iv
    one = iv.mpf(1)
    sqrt2 = iv.sqrt(2)
    kappa = one + sqrt2
    K = kappa * kappa
    # acos(1/3) = atan2(2 sqrt(2), 1), avoiding a missing iv.acos API.
    alpha = iv.atan2(2 * sqrt2, one)
    psi0 = -(2 * iv.pi / iv.sqrt(3)) * alpha
    return IntervalConstants(iv=iv, one=one, sqrt2=sqrt2, kappa=kappa, K=K, psi0=psi0)


def _endpoint_str(value: object, which: str, digits: int) -> str:
    if which == "lower":
        mpf_tuple = value._mpi_[0]
    elif which == "upper":
        mpf_tuple = value._mpi_[1]
    else:
        raise ValueError(which)
    return to_str(mpf_tuple, digits, strip_zeros=False)


def _interval_record(value: object, digits: int) -> dict[str, str]:
    return {
        "lower": _endpoint_str(value, "lower", digits),
        "upper": _endpoint_str(value, "upper", digits),
    }


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def stable_tail_integrand_interval(Q: object, X: object, c: IntervalConstants) -> tuple[object, dict[str, object]]:
    """Return interval H(Q,X) and domain diagnostics.

    Let kappa=1+sqrt(2), K=kappa^2 and rho=kappa/sqrt(q).  After scaling
    all divergent rho-powers, the exact fixed-interval Peabody integrand is

        H = (P_primary + P_correction) atan(Z) + Q_alg,

    with the quantities below.  The formula is algebraically identical for
    q>0 to the validated compressed-rho formula and extends continuously to
    q=0 without division by q.
    """
    iv, one, sqrt2, kappa, K = c.iv, c.one, c.sqrt2, c.kappa, c.K

    D2 = K * K + Q * Q
    R2 = K * K + Q * Q - 2 * K * Q * X * X
    T2 = 2 * K * (K * K + Q * Q) + K * K * (one - Q) * (one - Q) * X * X
    D = iv.sqrt(D2)
    R = iv.sqrt(R2)
    T = iv.sqrt(T2)

    delta_den = R + K - Q
    delta = 2 * K * (one - X * X) / delta_den

    # Mq = Mbar/q, written without division by q or cancellation at q=0.
    Mq = (
        K * (Q - 2 * K * X * X) / (R + K)
        + (one - K) * R
        - K * K
        - Q * R
        - Q
        - Q * Q
    )

    p_primary = -16 * sqrt2 * kappa * (K * K + Q * Q) / (R * T)
    p_correction = (
        -4
        * K
        * (one - Q * Q)
        * (K * K + Q * Q)
        * delta
        * Mq
        / (R * T * T * T)
    )
    q_alg = (
        -4
        * K
        * (one - Q * Q)
        * (K * K + Q * Q)
        * delta
        / (R * T * T)
    )

    angle_den = T * (K + Q + D)
    angle_num = K * ((one + Q) * D + (one - Q) * R)
    Z = angle_num / angle_den
    angle = iv.atan2(Z, one)
    H = (p_primary + p_correction) * angle + q_alg

    diagnostics = {
        "D2": D2,
        "R2": R2,
        "T2": T2,
        "delta_den": delta_den,
        "angle_den": angle_den,
        "angle_num": angle_num,
        "Z": Z,
    }
    return H, diagnostics


def run_certificate(
    output_dir: Path,
    precision_dps: int = DEFAULT_PRECISION,
    q_slabs: int = DEFAULT_Q_SLABS,
    x_panels: int = DEFAULT_X_PANELS,
    write_boxes: bool = True,
) -> dict[str, object]:
    start = time.time()
    output_dir.mkdir(parents=True, exist_ok=True)
    c = _setup(precision_dps)
    iv = c.iv

    terminal_boxes = q_slabs * x_panels
    if terminal_boxes > MAX_TERMINAL_BOXES:
        raise ValueError(f"terminal box count {terminal_boxes} exceeds {MAX_TERMINAL_BOXES}")

    q_den = q_slabs * Q_MAX_DENOMINATOR
    x_den = x_panels
    x_width = iv.mpf(1) / x_den
    target = iv.mpf(SIMPLE_RATIONAL_TARGET_NUMERATOR) / SIMPLE_RATIONAL_TARGET_DENOMINATOR

    full_Q = iv.mpf([0, q_slabs]) / q_den
    full_X = iv.mpf([0, x_panels]) / x_den
    _, global_diag = stable_tail_integrand_interval(full_Q, full_X, c)
    domain_positive = {
        key: bool(value.a > 0)
        for key, value in global_diag.items()
        if key in {"D2", "R2", "T2", "delta_den", "angle_den", "angle_num", "Z"}
    }

    box_path = output_dir / "tail_terminal_boxes.csv"
    slab_path = output_dir / "tail_slab_summary.csv"
    box_file = box_path.open("w", newline="", encoding="utf-8") if write_boxes else None
    box_writer = None
    if box_file is not None:
        box_writer = csv.DictWriter(
            box_file,
            fieldnames=[
                "q_slab_index",
                "x_panel_index",
                "q_lo_num",
                "q_hi_num",
                "q_den",
                "x_lo_num",
                "x_hi_num",
                "x_den",
                "h_lower",
                "h_upper",
                "contribution_lower",
                "contribution_upper",
            ],
        )
        box_writer.writeheader()

    slabs: list[dict[str, object]] = []
    worst_lower_interval = None
    worst_slab = None
    digits = precision_dps + 20

    try:
        for j in range(q_slabs):
            Q = iv.mpf([j, j + 1]) / q_den
            psi_enclosure = iv.mpf(0)
            for i in range(x_panels):
                X = iv.mpf([i, i + 1]) / x_den
                H, _ = stable_tail_integrand_interval(Q, X, c)
                contribution = H * x_width
                psi_enclosure += contribution
                if box_writer is not None:
                    box_writer.writerow(
                        {
                            "q_slab_index": j,
                            "x_panel_index": i,
                            "q_lo_num": j,
                            "q_hi_num": j + 1,
                            "q_den": q_den,
                            "x_lo_num": i,
                            "x_hi_num": i + 1,
                            "x_den": x_den,
                            "h_lower": _endpoint_str(H, "lower", digits),
                            "h_upper": _endpoint_str(H, "upper", digits),
                            "contribution_lower": _endpoint_str(contribution, "lower", digits),
                            "contribution_upper": _endpoint_str(contribution, "upper", digits),
                        }
                    )

            phi_enclosure = (psi_enclosure - c.psi0) / 8
            lower_interval = phi_enclosure.a
            if worst_lower_interval is None or bool(lower_interval < worst_lower_interval):
                worst_lower_interval = lower_interval
                worst_slab = j
            slabs.append(
                {
                    "q_slab_index": j,
                    "q_lo_num": j,
                    "q_hi_num": j + 1,
                    "q_den": q_den,
                    "psi_enclosure": _interval_record(psi_enclosure, digits),
                    "phi_enclosure": _interval_record(phi_enclosure, digits),
                    "strictly_positive": bool(phi_enclosure.a > 0),
                    "exceeds_simple_rational_target": bool(phi_enclosure.a > target.b),
                }
            )
    finally:
        if box_file is not None:
            box_file.close()

    with slab_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "q_slab_index",
                "q_lo_num",
                "q_hi_num",
                "q_den",
                "psi_lower",
                "psi_upper",
                "phi_lower",
                "phi_upper",
                "strictly_positive",
                "exceeds_simple_rational_target",
            ],
        )
        writer.writeheader()
        for row in slabs:
            writer.writerow(
                {
                    "q_slab_index": row["q_slab_index"],
                    "q_lo_num": row["q_lo_num"],
                    "q_hi_num": row["q_hi_num"],
                    "q_den": row["q_den"],
                    "psi_lower": row["psi_enclosure"]["lower"],
                    "psi_upper": row["psi_enclosure"]["upper"],
                    "phi_lower": row["phi_enclosure"]["lower"],
                    "phi_upper": row["phi_enclosure"]["upper"],
                    "strictly_positive": row["strictly_positive"],
                    "exceeds_simple_rational_target": row["exceeds_simple_rational_target"],
                }
            )

    all_positive = all(bool(row["strictly_positive"]) for row in slabs)
    all_above_target = all(bool(row["exceeds_simple_rational_target"]) for row in slabs)
    domain_pass = all(domain_positive.values())

    produced_files = [slab_path]
    if write_boxes:
        produced_files.append(box_path)
    certificate_bytes_pre_json = sum(p.stat().st_size for p in produced_files if p.exists())

    summary: dict[str, object] = {
        "formula_version": FORMULA_VERSION,
        "python_version": sys.version,
        "platform": platform.platform(),
        "mpmath_version": mp.__version__,
        "interval_precision_decimal_digits": precision_dps,
        "q_parameter": "q=(1-e)/(1+e)",
        "inverse_parameter": "e=(1-q)/(1+q)",
        "q_range": "0 <= q <= 1/399",
        "e_range_proved": "199/200 <= e < 1",
        "quantity_certified": "Phi(e)=(Psi(e)-Psi(0))/8",
        "method": "outward-rounded interval Riemann enclosure of the stable q-chart integrand",
        "q_slabs": q_slabs,
        "x_panels_per_slab": x_panels,
        "terminal_boxes": terminal_boxes,
        "maximum_terminal_boxes": MAX_TERMINAL_BOXES,
        "maximum_certificate_bytes": MAX_CERTIFICATE_BYTES,
        "q_endpoint_denominator": q_den,
        "x_endpoint_denominator": x_den,
        "psi0_enclosure": _interval_record(c.psi0, digits),
        "global_domain_diagnostics": {
            key: {
                **_interval_record(value, digits),
                "strictly_positive": domain_positive[key],
            }
            for key, value in global_diag.items()
            if key in domain_positive
        },
        "slabs": slabs,
        "worst_slab_index": worst_slab,
        "worst_certified_phi_lower": slabs[worst_slab]["phi_enclosure"]["lower"] if worst_slab is not None else None,
        "simple_rational_lower_bound": f"{SIMPLE_RATIONAL_TARGET_NUMERATOR}/{SIMPLE_RATIONAL_TARGET_DENOMINATOR}",
        "all_slabs_strictly_positive": all_positive,
        "all_slabs_exceed_simple_rational_lower_bound": all_above_target,
        "domain_safety_pass": domain_pass,
        "certificate_data_bytes_before_json": certificate_bytes_pre_json,
        "elapsed_seconds": time.time() - start,
        "proof_status": "CERTIFIED" if all_positive and domain_pass else "FAILED",
        "classification": (
            "GO_PEABODY_TAIL_PHI_POSITIVITY_CERTIFIED"
            if all_positive and domain_pass
            else "NO_GO_PEABODY_TAIL_CERTIFICATE_FAILED"
        ),
    }

    json_path = output_dir / "tail_certificate.json"
    produced_files.append(json_path)
    summary["certificate_data_bytes"] = 0
    summary["certificate_size_pass"] = True
    summary["hard_stop_pass"] = terminal_boxes <= MAX_TERMINAL_BOXES
    # Stabilize the self-reported size after serializing the size field itself.
    for _ in range(6):
        json_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
        total_bytes = sum(path.stat().st_size for path in produced_files if path.exists())
        size_pass = total_bytes <= MAX_CERTIFICATE_BYTES
        hard_stop_pass = terminal_boxes <= MAX_TERMINAL_BOXES and size_pass
        if (
            summary["certificate_data_bytes"] == total_bytes
            and summary["certificate_size_pass"] == size_pass
            and summary["hard_stop_pass"] == hard_stop_pass
        ):
            break
        summary["certificate_data_bytes"] = total_bytes
        summary["certificate_size_pass"] = size_pass
        summary["hard_stop_pass"] = hard_stop_pass
    if not summary["hard_stop_pass"]:
        summary["proof_status"] = "FAILED_HARD_STOP"
        summary["classification"] = "NO_GO_PEABODY_TAIL_CERTIFICATE_HARD_STOP"
    json_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    # Source-output hashes for deterministic replay.
    hash_rows = []
    for p in sorted(produced_files):
        if p.exists():
            hash_rows.append({"file": p.name, "sha256": _sha256(p), "bytes": p.stat().st_size})
    (output_dir / "tail_certificate_file_hashes.json").write_text(
        json.dumps(hash_rows, indent=2), encoding="utf-8"
    )
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--precision-dps", type=int, default=DEFAULT_PRECISION)
    parser.add_argument("--q-slabs", type=int, default=DEFAULT_Q_SLABS)
    parser.add_argument("--x-panels", type=int, default=DEFAULT_X_PANELS)
    parser.add_argument("--no-box-csv", action="store_true")
    args = parser.parse_args()
    result = run_certificate(
        output_dir=args.output_dir,
        precision_dps=args.precision_dps,
        q_slabs=args.q_slabs,
        x_panels=args.x_panels,
        write_boxes=not args.no_box_csv,
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
