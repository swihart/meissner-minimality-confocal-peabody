#!/usr/bin/env python3
"""Adversarial and cross-formula audit for the Peabody tail certificate."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import random
import sys
from pathlib import Path
from typing import Callable

import mpmath as mp

ROOT = Path(__file__).resolve().parent.parent
CERT_DIR = ROOT / "python"
sys.path.insert(0, str(CERT_DIR))
import peabody_tail_interval_certificate as tailcert

mp.mp.dps = 120
S2 = mp.sqrt(2)
KAPPA = 1 + S2
K = KAPPA**2


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def original_h_from_q(q: mp.mpf, x: mp.mpf) -> mp.mpf:
    if not (q > 0):
        raise ValueError("original e-chart requires q>0")
    e = (1 - q) / (1 + q)
    b2 = (3 + 4 * S2 * e + 3 * e * e) / (1 - e * e)
    b = mp.sqrt(b2)
    a = b / mp.sqrt(1 - e * e)
    amp = mp.sqrt(1 - x * x / b2)
    c = e * amp
    u = mp.sqrt(1 - 1 / b2)
    v = mp.sqrt(1 + 1 / b2)
    y = 1 / (mp.sqrt(b2 + 1) + b)
    angle = mp.atan(y * mp.sqrt((1 + c) / (1 - c)))
    kernel = 4 * angle / mp.sqrt(1 - c * c)
    core = kernel / a + e * (amp - u) / (1 - c * c) * (
        (v * c - 1) * kernel + 2 / b
    )
    return -4 * b * core / amp


def stable_h(q: mp.mpf, x: mp.mpf, drop_correction: bool = False) -> mp.mpf:
    D = mp.sqrt(K * K + q * q)
    R = mp.sqrt(K * K + q * q - 2 * K * q * x * x)
    T = mp.sqrt(2 * K * (K * K + q * q) + K * K * (1 - q) ** 2 * x * x)
    delta = 2 * K * (1 - x * x) / (R + K - q)
    Mq = (
        K * (q - 2 * K * x * x) / (R + K)
        + (1 - K) * R
        - K * K
        - q * R
        - q
        - q * q
    )
    p_primary = -16 * S2 * KAPPA * (K * K + q * q) / (R * T)
    p_correction = -4 * K * (1 - q * q) * (K * K + q * q) * delta * Mq / (R * T**3)
    q_alg = -4 * K * (1 - q * q) * (K * K + q * q) * delta / (R * T**2)
    z = K * ((1 + q) * D + (1 - q) * R) / (T * (K + q + D))
    if drop_correction:
        p_correction = mp.mpf("0")
    return (p_primary + p_correction) * mp.atan(z) + q_alg


def load_boxes(path: Path) -> dict[tuple[int, int], dict[str, str]]:
    out: dict[tuple[int, int], dict[str, str]] = {}
    with path.open(newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            key = (int(row["q_slab_index"]), int(row["x_panel_index"]))
            if key in out:
                raise RuntimeError(f"duplicate box {key}")
            out[key] = row
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--certificate-dir",
        type=Path,
        default=ROOT / "data" / "certificate_80dps",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "data" / "tail_certificate_audit.json",
    )
    args = parser.parse_args()

    cert_dir = args.certificate_dir
    summary = json.loads((cert_dir / "tail_certificate.json").read_text(encoding="utf-8"))
    boxes = load_boxes(cert_dir / "tail_terminal_boxes.csv")

    checks: dict[str, object] = {}
    checks["classification_is_go"] = summary["classification"] == "GO_PEABODY_TAIL_PHI_POSITIVITY_CERTIFIED"
    checks["proof_status_certified"] = summary["proof_status"] == "CERTIFIED"
    checks["box_count_exact"] = len(boxes) == 2000 == summary["terminal_boxes"]
    checks["hard_stop_pass"] = bool(summary["hard_stop_pass"])
    checks["simple_rational_target_pass"] = bool(summary["all_slabs_exceed_simple_rational_lower_bound"])

    # Verify archived output hashes.
    hash_rows = json.loads((cert_dir / "tail_certificate_file_hashes.json").read_text(encoding="utf-8"))
    hash_checks = {}
    for row in hash_rows:
        p = cert_dir / row["file"]
        hash_checks[row["file"]] = p.exists() and sha256(p) == row["sha256"] and p.stat().st_size == row["bytes"]
    checks["archived_hashes_pass"] = all(hash_checks.values())

    # Independent original-e versus stable-q cross-check.
    q_values = [mp.mpf(1) / 399, mp.mpf(1) / 500, mp.mpf(1) / 1000, mp.mpf("1e-4"), mp.mpf("1e-6")]
    x_values = [mp.mpf(0), mp.mpf("0.1"), mp.mpf("0.5"), mp.mpf("0.9"), mp.mpf(1)]
    max_cross_error = mp.mpf(0)
    max_mutation_error = mp.mpf(0)
    cross_rows = []
    for q in q_values:
        for x in x_values:
            original = original_h_from_q(q, x)
            stable = stable_h(q, x)
            mutated = stable_h(q, x, drop_correction=True)
            err = abs(original - stable)
            mutation_err = abs(original - mutated)
            max_cross_error = max(max_cross_error, err)
            max_mutation_error = max(max_mutation_error, mutation_err)
            cross_rows.append(
                {
                    "q": mp.nstr(q, 30),
                    "x": mp.nstr(x, 20),
                    "original_h": mp.nstr(original, 50),
                    "stable_h": mp.nstr(stable, 50),
                    "abs_difference": mp.nstr(err, 20),
                }
            )
    checks["original_vs_stable_max_error"] = mp.nstr(max_cross_error, 30)
    checks["original_vs_stable_pass"] = max_cross_error < mp.mpf("1e-90")
    checks["drop_correction_mutation_detected"] = max_mutation_error > mp.mpf("1e-3")
    checks["drop_correction_max_error"] = mp.nstr(max_mutation_error, 30)

    cross_csv = args.output.parent / "tail_original_vs_stable_crosscheck.csv"
    with cross_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(cross_rows[0]))
        writer.writeheader()
        writer.writerows(cross_rows)

    # Deterministic sample containment against the interval boxes.
    rng = random.Random(20260930)
    sample_keys = {(0, 0), (0, 399), (4, 0), (4, 399), (2, 200)}
    while len(sample_keys) < 80:
        sample_keys.add((rng.randrange(5), rng.randrange(400)))
    containment_failures = []
    max_gap = mp.mpf(0)
    for j, i in sorted(sample_keys):
        row = boxes[(j, i)]
        hlo = mp.mpf(row["h_lower"])
        hhi = mp.mpf(row["h_upper"])
        for q_num in [mp.mpf(j), mp.mpf(j) + mp.mpf("0.5"), mp.mpf(j + 1)]:
            q = q_num / 1995
            for x_num in [mp.mpf(i), mp.mpf(i) + mp.mpf("0.5"), mp.mpf(i + 1)]:
                x = x_num / 400
                val = stable_h(q, x)
                if not (hlo <= val <= hhi):
                    containment_failures.append({"j": j, "i": i, "q": mp.nstr(q, 30), "x": mp.nstr(x, 30), "value": mp.nstr(val, 50)})
                max_gap = max(max_gap, max(hlo - val, val - hhi, mp.mpf(0)))
    checks["sampled_box_containment_pass"] = not containment_failures
    checks["sampled_box_containment_failures"] = containment_failures[:5]
    checks["sampled_box_max_outside_gap"] = mp.nstr(max_gap, 20)

    # High-precision quadratures at each slab midpoint must lie in its enclosure.
    quad_rows = []
    quad_pass = True
    for slab in summary["slabs"]:
        j = int(slab["q_slab_index"])
        q = (mp.mpf(j) + mp.mpf("0.5")) / 1995
        psi = mp.quad(lambda xx: stable_h(q, xx), [0, 1])
        phi = (psi + (2 * mp.pi / mp.sqrt(3)) * mp.acos(mp.mpf(1) / 3)) / 8
        lo = mp.mpf(slab["phi_enclosure"]["lower"])
        hi = mp.mpf(slab["phi_enclosure"]["upper"])
        inside = lo <= phi <= hi
        quad_pass = quad_pass and inside
        quad_rows.append({"slab": j, "q_mid": mp.nstr(q, 30), "phi_point": mp.nstr(phi, 50), "lower": str(lo), "upper": str(hi), "inside": inside})
    checks["midpoint_quadrature_containment_pass"] = quad_pass
    checks["midpoint_quadratures"] = quad_rows

    # Precision replay at 100 digits, no terminal CSV.
    replay_dir = args.output.parent / "audit_replay_100dps"
    if replay_dir.exists():
        for p in replay_dir.iterdir():
            p.unlink()
    else:
        replay_dir.mkdir(parents=True)
    replay = tailcert.run_certificate(
        output_dir=replay_dir,
        precision_dps=100,
        q_slabs=5,
        x_panels=400,
        write_boxes=False,
    )
    checks["independent_100dps_replay_pass"] = replay["classification"] == "GO_PEABODY_TAIL_PHI_POSITIVITY_CERTIFIED"
    checks["independent_100dps_worst_lower"] = replay["worst_certified_phi_lower"]

    # Adversarial threshold control: replacing Psi(0) by Psi(0)+0.001 must fail.
    worst = mp.mpf(summary["worst_certified_phi_lower"])
    shifted = worst - mp.mpf("0.001") / 8
    checks["shifted_baseline_control_value"] = mp.nstr(shifted, 30)
    checks["shifted_baseline_control_fails"] = shifted < 0

    required_boolean_checks = [
        "classification_is_go",
        "proof_status_certified",
        "box_count_exact",
        "hard_stop_pass",
        "simple_rational_target_pass",
        "archived_hashes_pass",
        "original_vs_stable_pass",
        "drop_correction_mutation_detected",
        "sampled_box_containment_pass",
        "midpoint_quadrature_containment_pass",
        "independent_100dps_replay_pass",
        "shifted_baseline_control_fails",
    ]
    overall = all(bool(checks[k]) for k in required_boolean_checks)
    result = {
        "audit_pass": overall,
        "required_boolean_checks": required_boolean_checks,
        "checks": checks,
        "classification": "PEABODY_TAIL_CERTIFICATE_ADVERSARIAL_AUDIT_PASS" if overall else "PEABODY_TAIL_CERTIFICATE_ADVERSARIAL_AUDIT_FAIL",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
