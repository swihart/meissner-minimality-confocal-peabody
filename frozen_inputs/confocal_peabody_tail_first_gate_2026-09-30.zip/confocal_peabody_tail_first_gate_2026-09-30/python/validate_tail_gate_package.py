#!/usr/bin/env python3
"""Semantic and checksum validation for the Peabody tail-gate package."""
from __future__ import annotations
import hashlib, json
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent

def sha256(p:Path)->str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1<<20),b''): h.update(chunk)
    return h.hexdigest()

checksum_pass=True
for line in (ROOT/'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
    if not line.strip(): continue
    digest, rel=line.split('  ',1)
    p=ROOT/rel
    ok=p.exists() and sha256(p)==digest
    checksum_pass=checksum_pass and ok

result=json.loads((ROOT/'data/tail_gate_result.json').read_text())
cert=json.loads((ROOT/'data/certificate_80dps/tail_certificate.json').read_text())
audit=json.loads((ROOT/'data/tail_certificate_audit.json').read_text())
identity=json.loads((ROOT/'data/tail_chart_exact_identity_audit.json').read_text())
mandatory=json.loads((ROOT/'data/mandatory_v4_validation_replay.txt').read_text())
checks={
 'checksums_pass':checksum_pass,
 'mandatory_v4_replay_pass':mandatory['required_campaign_gates_pass'],
 'stable_chart_exact_identities_pass':identity['pass'],
 'tail_certificate_go':cert['classification']=='GO_PEABODY_TAIL_PHI_POSITIVITY_CERTIFIED',
 'tail_certificate_hard_stop_pass':cert['hard_stop_pass'],
 'adversarial_audit_pass':audit['audit_pass'],
 'result_classification_matches':result['final_classification']=='GO_PEABODY_TAIL_PHI_POSITIVITY_CERTIFIED',
 'central_not_started':result['central_certificate_started'] is False,
}
overall=all(checks.values())
out={'package_validation_pass':overall,'checks':checks,'classification':'PEABODY_TAIL_GATE_PACKAGE_VALIDATION_PASS' if overall else 'PEABODY_TAIL_GATE_PACKAGE_VALIDATION_FAIL'}
print(json.dumps(out,indent=2))
