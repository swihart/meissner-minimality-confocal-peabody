# Confocal Peabody v4 validated Mathematica checkpoint

## Status

The four Mathematica runs reached all **required campaign gates**:

1. the component diagnostic passed;
2. the broad compressed-formula audit passed;
3. the exact low-complexity integration-by-parts obstruction passed;
4. the central and tail interval-input scouts were numerical and positive.

The broad audit compared the original and compressed formulas on 35 pointwise
cases and six independent quadratures at 90-digit working precision. It also
checked the two compressed derivative constructions and recovered exact zero
for the T-sector primitive identities.

## Important caveat

The optional fixed-`rho` `Integrate` probe did **not** evaluate. The saved
`rt_sector_fixed_rho_primitive.wl` still contains an unevaluated `Integrate[...]`.
The original v4 script misclassified it because the `Integrate` was nested under
a scalar `Times` head. The corrected script
`wolfram/02_run_peabody_primitive_probe_v4_1.wl` uses a recursive `FreeQ` test.

This caveat does not affect the exact obstruction result. It means only that
Mathematica did not provide an explicit fixed-`rho` primitive or evidence about
which special functions such a primitive may require.

## What is established by this checkpoint

- The compressed exponential-rapidity implementation agrees with the original
  implementation to approximately 78--89 decimal digits on the archived tests.
- The T-sector rational primitive identities reduce exactly to zero.
- The frozen low-complexity rational ansatz for the RT sector is inconsistent
  at both `rho=3` and `rho=4`, so it cannot be a generic identity.
- The interval-certificate parameterization covers the full range by
  `0 <= e <= 199/200` and `0 < q <= 1/399`, where
  `q=(1-e)/(1+e)`.
- The sampled central derivative and tail-scaled derivative are positive.

## What is not established

- No interval certificate has yet been generated.
- Global positivity of `Phi'(e)` is not yet proved.
- Peabody-family minimality and global Meissner extremality remain unproved.

Run:

```bash
python3 python/validate_mathematica_outputs_v4.py
```

The script must report `required_campaign_gates_pass: true`. It deliberately
reports the optional fixed-`rho` integration as unevaluated.
