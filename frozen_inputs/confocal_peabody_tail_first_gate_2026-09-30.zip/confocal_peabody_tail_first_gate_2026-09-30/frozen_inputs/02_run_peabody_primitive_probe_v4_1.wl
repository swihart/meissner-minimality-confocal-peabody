(* ::Package:: *)

(*
  Run 02 v4: bounded primitive probe.

  This run requires the Run 01 PASS gate. It verifies the T-sector primitive
  over Q(Sqrt[2]), records the exact RT-sector obstruction, and performs one
  optional fixed-rho Integrate attempt capped at ten minutes.
*)

ClearAll["Global`*"];
$HistoryLength = 0;
$MaxExtraPrecision = 30000;

RunFixedRhoIntegrateProbe = True;
FixedRhoProbeValue = 3;
FixedRhoTimeLimitSeconds = 600;

supportInputDir = Quiet@Check[
  If[StringQ[$InputFileName] && StringLength[$InputFileName] > 0,
    DirectoryName[ExpandFileName[$InputFileName]],
    Missing["Unavailable"]
  ],
  Missing["Unavailable"]
];
supportNotebookDir = Quiet@Check[
  If[$FrontEnd =!= Null, NotebookDirectory[], Missing["Unavailable"]],
  Missing["Unavailable"]
];
supportCandidates = DeleteDuplicates@Select[
  {supportInputDir, supportNotebookDir, Quiet@Check[Directory[], Missing["Unavailable"]]},
  StringQ[#] && DirectoryQ[#] &
];
supportPath = SelectFirst[
  supportCandidates,
  FileExistsQ[FileNameJoin[{#, "peabody_replay_support_v4.wl"}]] &,
  Missing["NotFound"]
];
If[MissingQ[supportPath],
  Print["FATAL: peabody_replay_support_v4.wl was not found."];
  Abort[]
];
Get[FileNameJoin[{supportPath, "peabody_replay_support_v4.wl"}]];
baseDirectory = PeabodyV4ResolvePackageDirectory[];
corePath = PeabodyV4LoadCoreOrAbort[baseDirectory];
passGate = PeabodyV4RequireRun01PassOrAbort[baseDirectory];

outputDirectory = FileNameJoin[{baseDirectory, "mathematica_output_primitive_probe_v4"}];
If[! DirectoryQ[outputDirectory],
  CreateDirectory[outputDirectory, CreateIntermediateDirectories -> True]
];

reportStream = OpenWrite[
  FileNameJoin[{outputDirectory, "primitive_probe_report.txt"}],
  PageWidth -> Infinity
];
ClearAll[log];
log[msg_] := Module[{s = ToString[msg, InputForm]},
  Print[msg];
  WriteString[reportStream, s, "\n"];
  Flush[reportStream]
];

log["PEABODY COMPRESSED PRIMITIVE PROBE V4: START"];
log["Mathematica version: " <> ToString[$Version]];
log["Core path: " <> corePath];
log["Run 01 gate: " <> passGate];
log["Fixed rho probe: " <> ToString[FixedRhoProbeValue]];

(* Exact T-sector check. *)
tSectorResidualRaw = Together[
  2*zz*D[uZExpr, zz]
  + (1 + ecoefExpr*zz/t2ZExpr)*uZExpr
  - pArcFZExpr
];
tSectorReducedNumerator =
  PeabodyV4ReduceSqrt2Numerator[tSectorResidualRaw];
log["T-sector reduced numerator: " <>
  ToString[tSectorReducedNumerator, InputForm]];

(* Forced RT rational candidate and exact obstruction. *)
vCandidateZExpr =
  (v0CandidateExpr + v1CandidateExpr*zz)/(r2ZExpr*t2ZExpr^2);

rtCandidateResidual = Together[
  2*zz*D[vCandidateZExpr, zz]
  + (1 - b0Expr*zz/r2ZExpr + ecoefExpr*zz/t2ZExpr)*vCandidateZExpr
  - pArcGZExpr
];

obsZ2At3 = FullSimplify[obstructionZ2Expr /. rrho -> 3];
obsZ1At3 = FullSimplify[obstructionZ1Expr /. rrho -> 3];
obsZ2At4 = FullSimplify[obstructionZ2Expr /. rrho -> 4];
obsZ1At4 = FullSimplify[obstructionZ1Expr /. rrho -> 4];

Put[vCandidateZExpr,
  FileNameJoin[{outputDirectory, "forced_rt_rational_candidate_V.wl"}]
];
Put[rtCandidateResidual,
  FileNameJoin[{outputDirectory, "forced_rt_candidate_residual.wl"}]
];
Put[obstructionZ2Expr,
  FileNameJoin[{outputDirectory, "rt_obstruction_z2_exact.wl"}]
];
Put[obstructionZ1Expr,
  FileNameJoin[{outputDirectory, "rt_obstruction_z1_exact.wl"}]
];

log["RT obstruction z^2 at rho=3: " <> ToString[obsZ2At3, InputForm]];
log["RT obstruction z^1 at rho=3: " <> ToString[obsZ1At3, InputForm]];
log["RT obstruction z^2 at rho=4: " <> ToString[obsZ2At4, InputForm]];
log["RT obstruction z^1 at rho=4: " <> ToString[obsZ1At4, InputForm]];

rtSectorExpr =
  Sqrt[(r2ZExpr*t2ZExpr) /. zz -> xx^2]*(pArcGZExpr /. zz -> xx^2);
rtSectorFixed = FullSimplify[
  rtSectorExpr /. rrho -> FixedRhoProbeValue,
  Assumptions -> 0 < xx < 1
];
Put[rtSectorFixed,
  FileNameJoin[{outputDirectory, "rt_sector_fixed_rho_integrand.wl"}]
];

fixedPrimitive = If[TrueQ[RunFixedRhoIntegrateProbe],
  TimeConstrained[
    Integrate[rtSectorFixed, xx, GenerateConditions -> False],
    FixedRhoTimeLimitSeconds,
    $Aborted
  ],
  "SKIPPED"
];
Put[fixedPrimitive,
  FileNameJoin[{outputDirectory, "rt_sector_fixed_rho_primitive.wl"}]
];

fixedPrimitiveStatus = Which[
  fixedPrimitive === $Aborted, "$Aborted",
  fixedPrimitive === "SKIPPED", "SKIPPED",
  ! FreeQ[fixedPrimitive, Integrate[__]], "UNEVALUATED_INTEGRATE",
  True, "COMPLETED"
];

specialFunctionFlags = If[
  fixedPrimitiveStatus === "COMPLETED",
  <|
    "EllipticF" -> ! FreeQ[fixedPrimitive, EllipticF],
    "EllipticE" -> ! FreeQ[fixedPrimitive, EllipticE],
    "EllipticK" -> ! FreeQ[fixedPrimitive, EllipticK],
    "EllipticPi" -> ! FreeQ[fixedPrimitive, EllipticPi],
    "Hypergeometric" -> ! FreeQ[fixedPrimitive, HypergeometricPFQ]
  |>,
  <||>
];

fixedPrimitiveDerivativeResidual = If[
  fixedPrimitiveStatus === "COMPLETED",
  TimeConstrained[
    FullSimplify[
      D[fixedPrimitive, xx] - rtSectorFixed,
      Assumptions -> 0 < xx < 1
    ],
    300,
    $Aborted
  ],
  "NOT_AVAILABLE"
];
Put[fixedPrimitiveDerivativeResidual,
  FileNameJoin[{outputDirectory, "rt_fixed_primitive_derivative_residual.wl"}]
];

log["Fixed-rho Integrate status: " <> fixedPrimitiveStatus];
log["Special-function flags: " <> ToString[specialFunctionFlags, InputForm]];
log["Fixed primitive derivative residual: " <>
  ToString[fixedPrimitiveDerivativeResidual, InputForm]];

exactObstructionPass = TrueQ[
  tSectorReducedNumerator === 0 &&
  obsZ2At3 =!= 0 && obsZ1At3 =!= 0 &&
  obsZ2At4 =!= 0 && obsZ1At4 =!= 0
];

summary = <|
  "MathematicaVersion" -> $Version,
  "TSectorReducedNumerator" -> ToString[tSectorReducedNumerator, InputForm],
  "ObstructionZ2AtRho3" -> ToString[obsZ2At3, InputForm],
  "ObstructionZ1AtRho3" -> ToString[obsZ1At3, InputForm],
  "ObstructionZ2AtRho4" -> ToString[obsZ2At4, InputForm],
  "ObstructionZ1AtRho4" -> ToString[obsZ1At4, InputForm],
  "ExactLowComplexityObstructionPass" -> exactObstructionPass,
  "FixedRhoIntegrateStatus" -> fixedPrimitiveStatus,
  "SpecialFunctionFlags" -> specialFunctionFlags,
  "Classification" -> If[
    exactObstructionPass,
    "LOW_COMPLEXITY_ALGEBRAIC_IBP_PRIMITIVE_OBSTRUCTED",
    "PRIMITIVE_PROBE_V4_FAILED_DO_NOT_USE"
  ]
|>;

Put[summary,
  FileNameJoin[{outputDirectory, "primitive_probe_summary.wl"}]
];
Export[
  FileNameJoin[{outputDirectory, "primitive_probe_summary.json"}],
  summary,
  "RawJSON"
];

log["Exact low-complexity obstruction pass: " <>
  ToString[exactObstructionPass]];
log["PEABODY COMPRESSED PRIMITIVE PROBE V4: COMPLETE"];
Close[reportStream];
summary
