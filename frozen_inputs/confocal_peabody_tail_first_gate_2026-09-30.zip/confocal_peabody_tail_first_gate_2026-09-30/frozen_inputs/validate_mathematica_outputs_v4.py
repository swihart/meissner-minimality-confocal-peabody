#!/usr/bin/env python3
"""Validate the four Peabody v4 Mathematica output directories.

This script checks the intended campaign gates and separately detects whether
the optional fixed-rho Integrate probe actually evaluated. It does not prove
Phi'(e)>0; the interval-certificate inputs remain numerical/preparatory.
"""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "mathematica_outputs"

def load(name: str, file: str) -> dict:
    return json.loads((OUT / name / file).read_text())

component = load(
    "mathematica_output_component_diagnostic_v4",
    "component_diagnostic_summary.json",
)
compressed = load(
    "mathematica_output_compressed_audit_v4",
    "compressed_audit_summary.json",
)
primitive = load(
    "mathematica_output_primitive_probe_v4",
    "primitive_probe_summary.json",
)
intervals = load(
    "mathematica_output_interval_inputs_v4",
    "interval_input_summary.json",
)

primitive_file = (
    OUT
    / "mathematica_output_primitive_probe_v4"
    / "rt_sector_fixed_rho_primitive.wl"
)
primitive_text = primitive_file.read_text()
optional_integrate_evaluated = "Integrate[" not in primitive_text

checks = {
    "component_diagnostic_pass": component.get("Pass") is True,
    "compressed_audit_pass": compressed.get("Pass") is True,
    "run01_pass_marker_present": (
        OUT
        / "mathematica_output_compressed_audit_v4"
        / "RUN01_PASS.txt"
    ).is_file(),
    "exact_low_complexity_obstruction_pass": (
        primitive.get("ExactLowComplexityObstructionPass") is True
    ),
    "interval_numerical_scout_pass": intervals.get("NumericalScoutPass") is True,
    "interval_proof_still_not_certified": intervals.get("ProofStatus") == "NOT_CERTIFIED",
    "optional_fixed_rho_integrate_evaluated": optional_integrate_evaluated,
}

required = [
    "component_diagnostic_pass",
    "compressed_audit_pass",
    "run01_pass_marker_present",
    "exact_low_complexity_obstruction_pass",
    "interval_numerical_scout_pass",
    "interval_proof_still_not_certified",
]
required_pass = all(checks[k] for k in required)

report = {
    "required_campaign_gates_pass": required_pass,
    "checks": checks,
    "interpretation": {
        "compressed_formula": "independently high-precision validated",
        "t_sector_primitive": "exact symbolic identity passed",
        "rt_low_complexity_ansatz": "exactly obstructed at rho=3 and rho=4",
        "optional_fixed_rho_integrate": (
            "evaluated" if optional_integrate_evaluated else "unevaluated; original v4 status was misclassified"
        ),
        "interval_inputs": "conditioned and numerically positive on scout grids, not certified",
    },
}

path = ROOT / "data" / "validated_output_summary.json"
path.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
raise SystemExit(0 if required_pass else 1)
