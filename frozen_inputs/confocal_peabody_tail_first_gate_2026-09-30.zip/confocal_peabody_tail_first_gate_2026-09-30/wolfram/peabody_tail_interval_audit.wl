(* ::Package:: *)

(*
  Independent Mathematica interval replay for the Confocal Peabody tail gate.

  This file performs no Integrate, NIntegrate, FullSimplify, or unrestricted
  symbolic search.  It mirrors the finite 5 x 400 outward interval Riemann
  enclosure used by the Python proof authority.

  Target:
      Phi((1-q)/(1+q)) > 1/20000,  0 <= q <= 1/399.
*)

ClearAll["Global`*"];
$HistoryLength = 0;
$MaxExtraPrecision = 20000;
wp = 90;

baseDirectory = If[
  StringQ[$InputFileName] && StringLength[$InputFileName] > 0,
  DirectoryName[ExpandFileName[$InputFileName]],
  Quiet@Check[NotebookDirectory[], Directory[]]
];
outputDirectory = FileNameJoin[{baseDirectory, "mathematica_output_tail_interval_audit"}];
If[!DirectoryQ[outputDirectory], CreateDirectory[outputDirectory, CreateIntermediateDirectories -> True]];

reportStream = OpenWrite[FileNameJoin[{outputDirectory, "tail_interval_audit_report.txt"}], PageWidth -> Infinity];
ClearAll[log];
log[msg_] := Module[{s = ToString[msg, InputForm]}, Print[msg]; WriteString[reportStream, s, "\n"]; Flush[reportStream]];

ClearAll[intervalLower, intervalUpper];
intervalLower[z_Interval] := z[[1, 1]];
intervalUpper[z_Interval] := z[[1, 2]];

sqrt2 = Sqrt[2];
kappa = Plus[1, sqrt2];
K = kappa^2;
one = 1;

ClearAll[tailH];
tailH[Q_Interval, X_Interval] := Module[
  {D2, R2, T2, D, R, T, deltaDen, delta, Mq, pPrimary,
   pCorrection, qAlg, angleDen, angleNum, Z, angle, H},
  D2 = Plus[K^2, Q^2];
  R2 = Plus[K^2, Q^2, Times[-2, K, Q, X^2]];
  T2 = Plus[Times[2, K, Plus[K^2, Q^2]], Times[K^2, (one - Q)^2, X^2]];
  D = Sqrt[D2];
  R = Sqrt[R2];
  T = Sqrt[T2];
  deltaDen = Plus[R, K, -Q];
  delta = Times[2, K, Plus[one, -X^2], Power[deltaDen, -1]];
  Mq = Plus[
    Times[K, Plus[Q, Times[-2, K, X^2]], Power[Plus[R, K], -1]],
    Times[Plus[one, -K], R],
    -K^2,
    Times[-1, Q, R],
    -Q,
    -Q^2
  ];
  pPrimary = Times[-16, sqrt2, kappa, Plus[K^2, Q^2], Power[R, -1], Power[T, -1]];
  pCorrection = Times[
    -4, K, Plus[one, -Q^2], Plus[K^2, Q^2], delta, Mq,
    Power[R, -1], Power[T, -3]
  ];
  qAlg = Times[
    -4, K, Plus[one, -Q^2], Plus[K^2, Q^2], delta,
    Power[R, -1], Power[T, -2]
  ];
  angleDen = Times[T, Plus[K, Q, D]];
  angleNum = Times[K, Plus[Times[Plus[one, Q], D], Times[Plus[one, -Q], R]]];
  Z = Times[angleNum, Power[angleDen, -1]];
  angle = ArcTan[Z];
  H = Plus[Times[Plus[pPrimary, pCorrection], angle], qAlg];
  N[H, wp]
];

qSlabs = 5;
xPanels = 400;
qDen = qSlabs*399;
xDen = xPanels;
xWidth = Rational[1, xDen];
psi0 = N[Times[-2, Pi, Power[Sqrt[3], -1], ArcCos[Rational[1, 3]]], wp];
target = Rational[1, 20000];

log["PEABODY TAIL INTERVAL AUDIT: START"];
log["Mathematica version: " <> ToString[$Version]];
log["q slabs: " <> ToString[qSlabs] <> "; x panels: " <> ToString[xPanels]];

slabRows = Table[
  Module[{Q, psi, phi, lo, hi},
    Q = N[Interval[{{Rational[j, qDen], Rational[j + 1, qDen]}}], wp];
    psi = Interval[{{0, 0}}];
    Do[
      psi = Plus[
        psi,
        Times[
          tailH[Q, N[Interval[{{Rational[i, xDen], Rational[i + 1, xDen]}}], wp]],
          xWidth
        ]
      ],
      {i, 0, xPanels - 1}
    ];
    phi = N[Times[Rational[1, 8], Plus[psi, -psi0]], wp];
    lo = intervalLower[phi];
    hi = intervalUpper[phi];
    log["Slab " <> ToString[j] <> " Phi interval: " <> ToString[phi, InputForm]];
    {j, Rational[j, qDen], Rational[j + 1, qDen], lo, hi, TrueQ[lo > target]}
  ],
  {j, 0, qSlabs - 1}
];

pass = And @@ slabRows[[All, 6]];
Export[
  FileNameJoin[{outputDirectory, "tail_interval_audit_slabs.csv"}],
  Prepend[slabRows, {"slab", "q_lo", "q_hi", "phi_lower", "phi_upper", "above_1_over_20000"}],
  "CSV"
];
summary = <|
  "MathematicaVersion" -> $Version,
  "QSlabs" -> qSlabs,
  "XPanels" -> xPanels,
  "TerminalBoxes" -> qSlabs*xPanels,
  "Target" -> "1/20000",
  "WorstLower" -> ToString[Min[slabRows[[All, 4]]], InputForm],
  "Pass" -> pass,
  "Classification" -> If[pass, "PEABODY_TAIL_INTERVAL_AUDIT_PASS", "PEABODY_TAIL_INTERVAL_AUDIT_FAIL"]
|>;
Export[FileNameJoin[{outputDirectory, "tail_interval_audit_summary.json"}], summary, "RawJSON"];
Put[summary, FileNameJoin[{outputDirectory, "tail_interval_audit_summary.wl"}]];
log["Tail interval audit pass: " <> ToString[pass]];
log["PEABODY TAIL INTERVAL AUDIT: COMPLETE"];
Close[reportStream];
summary
