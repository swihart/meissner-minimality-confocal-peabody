# Git integration

This package should sit on top of the validated v4 Peabody checkpoint and remain separate from the bottom-up spectral-refinements repository.

Recommended branch:

```text
work/confocal-peabody-tail-certificate
```

Recommended commit message:

```text
Certify positivity on the confocal Peabody tail
```

From the selected Peabody/top-down repository root:

```bash
git switch -c work/confocal-peabody-tail-certificate
mkdir -p research/confocal_peabody_tail_certificate
cp -R /path/to/confocal_peabody_tail_first_gate_2026-09-30/. \
  research/confocal_peabody_tail_certificate/
git add research/confocal_peabody_tail_certificate
git status --short
git commit -m "Certify positivity on the confocal Peabody tail"
```

Do not promote a full Peabody-family minimum yet. The certified result covers only

```text
199/200 <= e < 1.
```

The central interval remains unresolved and must be handled in a separate theorem-sized step.
