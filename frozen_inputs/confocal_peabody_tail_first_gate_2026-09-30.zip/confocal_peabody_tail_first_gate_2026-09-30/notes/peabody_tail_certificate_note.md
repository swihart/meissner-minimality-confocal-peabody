# Confocal Peabody tail-first certification gate

**Date:** 2026-09-30  
**Scope:** regular-tetrahedron confocal Peabodies only  
**Final tail classification:** `GO_PEABODY_TAIL_PHI_POSITIVITY_CERTIFIED`

## 1. Result

Let

\[
q=\frac{1-e}{1+e},\qquad e=\frac{1-q}{1+q},
\]

and let

\[
\Phi(e)=\frac{\Psi(e)-\Psi(0)}8
\]

be the frozen one-pair width-one volume increment from the validated Peabody formula.
A finite outward-rounded interval calculation proves

\[
\boxed{
\Phi(e)>\frac1{20000}>0
\qquad\left(\frac{199}{200}\le e<1\right).
}
\]

Equivalently, the certificate covers

\[
0<q\le\frac1{399}.
\]

The same stable expression extends continuously to `q=0`; this endpoint is included in the compact interval calculation only to close the tail chart. The Peabody family itself uses `e<1`, hence `q>0`.

This is a **direct positivity certificate for `Phi`**. It does not prove `Phi'(e)>0` on the tail, and no derivative claim is needed for this gate.

## 2. Mandatory checkpoint replay

Before new certification work, the frozen validator

```bash
python3 python/validate_mathematica_outputs_v4.py
```

was replayed against the complete validated v4 checkpoint. It reported:

```text
required_campaign_gates_pass: true
optional_fixed_rho_integrate_evaluated: false
interval_proof_still_not_certified: true
```

Thus the compressed formula was accepted as the frozen input, while the unevaluated fixed-`rho` `Integrate` probe was not used.

## 3. Why direct `Phi` positivity was chosen

The tail-scaled derivative

\[
\frac{\Phi'(e)}{1-e}
\]

is numerically positive, but its fixed-interval integrand changes sign and exhibits severe cancellation. The frozen campaign rules state that derivative positivity is sufficient but not necessary. On the tail, `Phi` itself is separated from zero by roughly `3.78e-4`, so certifying `Phi>0` directly is both sharper strategically and substantially better conditioned.

No unrestricted symbolic integration, `FullSimplify`, special-function search, or higher-degree retry of the obstructed rational integration-by-parts ansatz was performed.

## 4. Stable tail chart

Put

\[
\kappa=1+\sqrt2,\qquad K=\kappa^2,
\]

and use the exponential-rapidity relation

\[
\rho=\frac{\kappa}{\sqrt q}.
\]

For `q>0`, the validated compact `rho`-integrand can be rewritten without negative powers of `q`. For `0<=x<=1`, define

\[
D=\sqrt{K^2+q^2},
\]

\[
R=\sqrt{K^2+q^2-2Kqx^2},
\]

\[
T=\sqrt{2K(K^2+q^2)+K^2(1-q)^2x^2}.
\]

The cancellation-prone quantity

\[
r-\rho^2+1
\]

becomes the stable expression

\[
\delta=\frac{2K(1-x^2)}{R+K-q},
\]

because

\[
R^2-(K-q)^2=2Kq(1-x^2).
\]

Likewise, writing the scaled auxiliary factor as

\[
M=
\frac{K(q-2Kx^2)}{R+K}
 +(1-K)R-K^2-qR-q-q^2
\]

removes the remaining division by `q`.

Define

\[
P_1=-\frac{16\sqrt2\,\kappa(K^2+q^2)}{RT},
\]

\[
P_2=-\frac{4K(1-q^2)(K^2+q^2)\delta M}{RT^3},
\]

\[
Q_0=-\frac{4K(1-q^2)(K^2+q^2)\delta}{RT^2},
\]

and

\[
Z=\frac{K\big((1+q)D+(1-q)R\big)}{T(K+q+D)}.
\]

Then the exact fixed-interval pair integrand is

\[
\boxed{
H(q,x)=(P_1+P_2)\arctan Z+Q_0,
}
\]

with

\[
\Psi\!\left(\frac{1-q}{1+q}\right)=\int_0^1 H(q,x)\,dx.
\]

Every displayed denominator is strictly positive on

\[
0\le q\le\frac1{399},\qquad 0\le x\le1.
\]

The certificate independently encloses the relevant radicands, denominators, and `Z` away from zero. The formula therefore extends continuously to `q=0` and has no `ArcTan` branch ambiguity: `Z>0` throughout the certified rectangle.

## 5. Finite certificate

The proof uses the exact rational partition

\[
Q_j=\left[\frac{j}{1995},\frac{j+1}{1995}\right],
\qquad j=0,\ldots,4,
\]

and

\[
X_i=\left[\frac{i}{400},\frac{i+1}{400}\right],
\qquad i=0,\ldots,399.
\]

For each of the `2,000` rectangles `Q_j x X_i`, 80-decimal-digit `mpmath.iv` arithmetic evaluates an outward-rounded interval extension of `H`. For fixed `Q_j`, the interval Riemann sum

\[
I_j=\sum_{i=0}^{399}\frac1{400}H(Q_j,X_i)
\]

encloses

\[
\int_0^1H(q,x)\,dx
\]

simultaneously for every `q in Q_j`. The exact Meissner value

\[
\Psi(0)=-\frac{2\pi}{\sqrt3}\arccos\frac13
\]

is enclosed independently, and

\[
\frac{I_j-\Psi(0)}8
\]

gives the following rigorous lower endpoints.

| Tail slab `j` | `q` interval | Certified lower endpoint for `Phi` |
|---:|---|---:|
| 0 | `[0,1/1995]` | `0.0000608548550752924016845757616614...` |
| 1 | `[1/1995,2/1995]` | `0.0000607779701312853100116002193251...` |
| 2 | `[2/1995,3/1995]` | `0.0000607009285081983263036085375001...` |
| 3 | `[3/1995,4/1995]` | `0.0000606237302314365306697131718669...` |
| 4 | `[4/1995,5/1995]` | `0.0000605463753264279646801098559647...` |

The weakest lower endpoint is therefore above

\[
\frac1{20000}=0.00005.
\]

## 6. Hard-stop accounting

| Metric | Frozen maximum | Actual |
|---|---:|---:|
| Terminal interval boxes | 5,000 | **2,000** |
| Certificate data | 10,000,000 bytes | **896,282 bytes** |

The gate stays comfortably inside both frozen limits.

## 7. Independent and adversarial validation

The archived audit passed all of the following:

1. exact SymPy polynomial reductions for the stable `delta`, scaled `M`, and squared `ArcTan`-argument identities, all with remainder zero;
2. replay of the v4 Mathematica-output validator;
3. independent 120-digit comparison of the stable `q` formula with the original `e` formula, with maximum discrepancy `1.39e-115` on the audit grid;
4. deterministic containment checks at 80 sampled terminal boxes and nine points per box;
5. 120-digit quadratures at all five slab midpoints, each lying inside the certified slab enclosure;
6. a complete 100-digit interval replay reproducing the same weakest lower endpoint;
7. a mutation control deleting the ArcTan correction sector, detected by an error above `0.305`;
8. a shifted-baseline control, which correctly changes the certified lower margin to a negative number;
9. SHA-256 verification of all certificate outputs.

Precision replays at 60, 80, and 100 decimal digits all returned the same positive lower digits and the same weakest slab.

## 8. Claim ledger

| Category | Claim |
|---|---|
| **ESTABLISHED FROM SOURCES** | Peabodies assembled from the six wedge-pod surfaces and four caps are bodies of constant width; the Meissner bodies occur as the circle-line degeneration. |
| **FROZEN PROJECT DERIVATION** | `V=V_M+Phi(e1)+Phi(e2)+Phi(e3)`, independent of orientation bits. |
| **CERTIFIED IN THIS GATE** | `Phi(e)>1/20000` for every `199/200 <= e < 1`. |
| **NOT CLAIMED** | Tail monotonicity `Phi'(e)>0`; positivity on the central interval; complete Peabody-family minimality; global Meissner extremality; any universal lower-bound improvement. |

## 9. Final gate decision

```text
GO_PEABODY_TAIL_PHI_POSITIVITY_CERTIFIED
```

The tail is closed by direct positivity of `Phi`. The full central certificate may now begin in a separate theorem-sized step, using the frozen tail result rather than attempting further tail symbolic work.
