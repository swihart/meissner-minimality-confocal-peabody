# Confocal Peabody tail-first certification gate

## Final status

```text
GO_PEABODY_TAIL_PHI_POSITIVITY_CERTIFIED
```

The package certifies

\[
\Phi(e)>\frac1{20000}
\qquad\text{for every }\frac{199}{200}\le e<1.
\]

This is a restricted-family tail theorem. It does not prove tail monotonicity, central positivity, complete Peabody-family minimality, global Meissner extremality, or a universal lower-bound improvement.

## Mandatory replay

The frozen v4 validator was run before the new certificate. Its transcript is in

```text
data/mandatory_v4_validation_replay.txt
```

and reports `required_campaign_gates_pass: true` and `optional_fixed_rho_integrate_evaluated: false`.

## Proof authority

Run from the package root:

```bash
python3 python/peabody_tail_interval_certificate.py \
  --output-dir data/replay_certificate_80dps \
  --precision-dps 80 \
  --q-slabs 5 \
  --x-panels 400
```

Expected classification:

```text
GO_PEABODY_TAIL_PHI_POSITIVITY_CERTIFIED
```

The canonical archived proof output is under

```text
data/certificate_80dps/
```

and uses 2,000 terminal boxes and less than 1 MB of proof data.

## Adversarial audit

```bash
python3 python/audit_peabody_tail_certificate.py \
  --certificate-dir data/certificate_80dps \
  --output data/replay_tail_certificate_audit.json
```

Expected classification:

```text
PEABODY_TAIL_CERTIFICATE_ADVERSARIAL_AUDIT_PASS
```

## Optional Mathematica replay

From a fresh Mathematica kernel:

```wl
Get["/full/path/to/wolfram/peabody_tail_interval_audit.wl"]
```

This is an independent audit of the same finite 5-by-400 interval partition. The Python `mpmath.iv` calculation is the archived proof authority; the Mathematica file is not needed for the logical certificate.

## Main files

- `notes/peabody_tail_certificate_note.md`: derivation, theorem statement, and claim ledger;
- `python/peabody_tail_interval_certificate.py`: proof-authority certifier;
- `python/audit_peabody_tail_certificate.py`: cross-formula and adversarial replay;
- `python/verify_tail_chart_algebra.py`: exact polynomial-reduction checks for the stable tail chart;
- `python/validate_tail_gate_package.py`: checksums and semantic package validation;
- `wolfram/peabody_tail_interval_audit.wl`: optional independent interval audit;
- `data/certificate_80dps/tail_certificate.json`: machine-readable certificate summary;
- `data/certificate_80dps/tail_terminal_boxes.csv`: all 2,000 terminal interval records;
- `data/tail_certificate_audit.json`: completed adversarial audit;
- `data/tail_chart_exact_identity_audit.json`: exact stable-chart identity results;
- `SHA256SUMS.txt`: portable package checksums.

## Hard stop

The frozen tail limits were 5,000 terminal boxes and 10 MB of certificate data. Actual use was 2,000 boxes and 896,282 bytes. No full central-interval certificate was started in this gate.
