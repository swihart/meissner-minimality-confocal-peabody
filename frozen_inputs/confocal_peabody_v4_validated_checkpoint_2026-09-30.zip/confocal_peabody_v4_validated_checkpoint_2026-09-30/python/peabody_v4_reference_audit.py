#!/usr/bin/env python3
"""Independent reference audit for the v4 Wolfram replay package."""
from __future__ import annotations
import json
from pathlib import Path
from typing import Callable
import mpmath as mp
import sympy as sp

ROOT = Path(__file__).resolve().parent
mp.mp.dps = 90
S2 = mp.sqrt(2)
K = 1 + S2

def rho_from_e(e: mp.mpf) -> mp.mpf:
    return K*mp.sqrt((1+e)/(1-e))

def original_components(e: mp.mpf, x: mp.mpf) -> tuple[mp.mpf, mp.mpf, mp.mpf, mp.mpf]:
    b2=(3+4*S2*e+3*e*e)/(1-e*e)
    b=mp.sqrt(b2); a=b/mp.sqrt(1-e*e); amp=mp.sqrt(1-x*x/b2)
    c=e*amp; u=mp.sqrt(1-1/b2); v=mp.sqrt(1+1/b2)
    y=1/(mp.sqrt(b2+1)+b); angle=mp.atan(y*mp.sqrt((1+c)/(1-c)))
    kernel=4*angle/mp.sqrt(1-c*c); outer=e*(amp-u)/(1-c*c)
    primary=(-4*b/amp)*(kernel/a)
    correction=(-4*b/amp)*(outer*((v*c-1)*kernel))
    alg=(-4*b/amp)*(outer*(2/b))
    return primary,correction,alg,primary+correction+alg

def compact_fields(rho: mp.mpf, x: mp.mpf) -> dict[str,mp.mpf]:
    d2=rho**4+1; d=mp.sqrt(d2); r2=d2-2*rho**2*x*x; r=mp.sqrt(r2)
    am=rho**2-K**2; ap=rho**2+K**2; t2=2*K**2*d2+am**2*x*x; t=mp.sqrt(t2)
    delta=r-rho**2+1; m=am*(rho**2+1)*r-ap*d2
    c=am*r/(ap*d); y=(rho**2+1-d)/(S2*rho); angle=mp.atan(y*mp.sqrt((1+c)/(1-c)))
    p1=-16*S2*K*d2/(r*t)
    p2=-4*am*ap*d2*delta*m/(rho**4*r*t**3)
    q=-4*am*ap*d2*delta/(rho**2*r*t2)
    return {'primary':p1*angle,'correction':p2*angle,'alg':q,'total':(p1+p2)*angle+q,
            'p0':p1+p2,'angle':angle,'q0':q}

def build_p_arc_function():
    rho,z=sp.symbols('rho z', positive=True)
    s2=sp.sqrt(2); k=1+s2
    d2=rho**4+1; r2=d2-2*rho**2*z; am=rho**2-k**2; ap=rho**2+k**2
    t2=2*k**2*d2+am**2*z; h0=rho**2-1
    bcoef=am*(rho**2+1); ccoef=ap*d2; pref=-4*am*ap*d2/rho**4
    nf=-pref*(ccoef+h0*bcoef)
    fnum=sp.expand(rho*(sp.diff(nf,rho)*t2-sp.Rational(3,2)*nf*sp.diff(t2,rho)))
    F=fnum/t2**3
    a1=-16*s2*k*d2; a2=pref*bcoef; a3=pref*h0*ccoef
    ng=sp.expand(a1*t2+a2*r2+a3)
    gnum=sp.expand(rho*(sp.diff(ng,rho)*r2*t2-sp.Rational(1,2)*ng*sp.diff(r2,rho)*t2-sp.Rational(3,2)*ng*sp.diff(t2,rho)*r2))
    G=gnum/(r2**2*t2**3)
    p_arc=sp.sqrt(t2)*F+sp.sqrt(r2*t2)*G
    return sp.lambdify((rho,z),p_arc,'mpmath')

P_ARC = build_p_arc_function()

def sector_lambda_derivative(rho: mp.mpf,x: mp.mpf)->mp.mpf:
    f=compact_fields(rho,x)
    p_arc=P_ARC(rho,x*x)
    q_fun:Callable[[mp.mpf],mp.mpf]=lambda r: compact_fields(r,x)['q0']
    a_fun:Callable[[mp.mpf],mp.mpf]=lambda r: compact_fields(r,x)['angle']
    q_alg=rho*mp.diff(q_fun,rho)+rho*f['p0']*mp.diff(a_fun,rho)
    return p_arc*f['angle']+q_alg

def main() -> None:
    maxerrs=[mp.mpf('0')]*4
    max_orig_compact_deriv=mp.mpf('0')
    max_direct_sector_deriv=mp.mpf('0')
    for e in map(mp.mpf,['0','0.001','0.1','0.5','0.9','0.99','0.999']):
        rho=rho_from_e(e)
        for x in map(mp.mpf,['0','0.1','0.5','0.9','1']):
            o=original_components(e,x); cf=compact_fields(rho,x); c=(cf['primary'],cf['correction'],cf['alg'],cf['total'])
            maxerrs=[max(a,abs(b-d)) for a,b,d in zip(maxerrs,o,c)]
            lam=mp.atanh(e)
            d_orig=mp.diff(lambda t: original_components(mp.tanh(t),x)[3],lam)
            d_direct=rho*mp.diff(lambda r: compact_fields(r,x)['total'],rho)
            d_sector=sector_lambda_derivative(rho,x)
            max_orig_compact_deriv=max(max_orig_compact_deriv,abs(d_orig-d_direct))
            max_direct_sector_deriv=max(max_direct_sector_deriv,abs(d_direct-d_sector))
    summary={
      'working_precision_digits':mp.mp.dps,
      'maximum_primary_arc_error':mp.nstr(maxerrs[0],25),
      'maximum_correction_arc_error':mp.nstr(maxerrs[1],25),
      'maximum_algebraic_error':mp.nstr(maxerrs[2],25),
      'maximum_total_error':mp.nstr(maxerrs[3],25),
      'maximum_original_vs_compact_derivative_error':mp.nstr(max_orig_compact_deriv,25),
      'maximum_direct_vs_sector_derivative_error':mp.nstr(max_direct_sector_deriv,25),
      'classification':'V4_REFERENCE_COMPONENT_AND_DERIVATIVE_AUDIT_PASS'
    }
    (ROOT/'v4_reference_audit.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))
if __name__=='__main__': main()
