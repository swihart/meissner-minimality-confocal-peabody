(* ::Package:: *)

ClearAll["Global`*"];
$HistoryLength = 0;
$MaxExtraPrecision = 30000;

supportInputDir = Quiet@Check[
  If[StringQ[$InputFileName] && StringLength[$InputFileName] > 0,
    DirectoryName[ExpandFileName[$InputFileName]],
    Missing["Unavailable"]
  ],
  Missing["Unavailable"]
];
supportNotebookDir = Quiet@Check[
  If[$FrontEnd =!= Null, NotebookDirectory[], Missing["Unavailable"]],
  Missing["Unavailable"]
];
supportCandidates = DeleteDuplicates@Select[
  {supportInputDir, supportNotebookDir, Quiet@Check[Directory[], Missing["Unavailable"]]},
  StringQ[#] && DirectoryQ[#] &
];
supportPath = SelectFirst[
  supportCandidates,
  FileExistsQ[FileNameJoin[{#, "peabody_replay_support_v4.wl"}]] &,
  Missing["NotFound"]
];
If[MissingQ[supportPath],
  Print["FATAL: peabody_replay_support_v4.wl was not found."];
  Abort[]
];
Get[FileNameJoin[{supportPath, "peabody_replay_support_v4.wl"}]];
baseDirectory = PeabodyV4ResolvePackageDirectory[];
corePath = PeabodyV4LoadCoreOrAbort[baseDirectory];

outputDirectory = FileNameJoin[{baseDirectory, "mathematica_output_component_diagnostic_v4"}];
If[! DirectoryQ[outputDirectory],
  CreateDirectory[outputDirectory, CreateIntermediateDirectories -> True]
];

reportStream = OpenWrite[
  FileNameJoin[{outputDirectory, "component_diagnostic_report.txt"}],
  PageWidth -> Infinity
];
ClearAll[log];
log[msg_] := Module[{s = ToString[msg, InputForm]},
  Print[msg];
  WriteString[reportStream, s, "\n"];
  Flush[reportStream]
];

log["PEABODY V4 COMPONENT DIAGNOSTIC: START"];
log["Mathematica version: " <> ToString[$Version]];
log["Core path: " <> corePath];

ClearAll[
  ee, b2O, bO, aO, ampO, cO, uO, vO, yO,
  angleO, kernelO, outerO,
  hOriginalArcPrimaryExpr, hOriginalArcCorrectionExpr,
  hOriginalArcExpr, hOriginalAlgebraicExpr, hOriginalTotalExpr,
  dHdLambdaOriginalExpr
];

b2O = (3 + 4*Sqrt[2]*ee + 3*ee^2)/(1 - ee^2);
bO = Sqrt[b2O];
aO = bO/Sqrt[1 - ee^2];
ampO = Sqrt[1 - xx^2/b2O];
cO = ee*ampO;
uO = Sqrt[1 - 1/b2O];
vO = Sqrt[1 + 1/b2O];
yO = 1/(Sqrt[b2O + 1] + bO);
angleO = ArcTan[yO*Sqrt[(1 + cO)/(1 - cO)]];
kernelO = 4*angleO/Sqrt[1 - cO^2];
outerO = ee*(ampO - uO)/(1 - cO^2);

hOriginalArcPrimaryExpr = Times[-4, bO, Power[ampO, -1], kernelO, Power[aO, -1]];
hOriginalArcCorrectionExpr = Times[
  -4, bO, Power[ampO, -1], outerO,
  Plus[Times[vO, cO], -1], kernelO
];
hOriginalArcExpr = Plus[hOriginalArcPrimaryExpr, hOriginalArcCorrectionExpr];
hOriginalAlgebraicExpr = Times[-4, bO, Power[ampO, -1], outerO, 2, Power[bO, -1]];
hOriginalTotalExpr = Plus[hOriginalArcExpr, hOriginalAlgebraicExpr];
dHdLambdaOriginalExpr = (1 - ee^2)*D[hOriginalTotalExpr, ee];

wp = 90;
ep = N[9/10, wp];
xp0 = N[0, wp];
xpD = N[1/2, wp];
rp = N[rhoFromE[ep], wp];

origPrimary = N[hOriginalArcPrimaryExpr /. {ee -> ep, xx -> xp0}, wp];
origCorrection = N[hOriginalArcCorrectionExpr /. {ee -> ep, xx -> xp0}, wp];
origAlg = N[hOriginalAlgebraicExpr /. {ee -> ep, xx -> xp0}, wp];
origTotal = N[hOriginalTotalExpr /. {ee -> ep, xx -> xp0}, wp];

compactPrimary = N[hCompactArcPrimaryExpr /. {rrho -> rp, xx -> xp0}, wp];
compactCorrection = N[hCompactArcCorrectionExpr /. {rrho -> rp, xx -> xp0}, wp];
compactAlg = N[hCompactAlgebraicExpr /. {rrho -> rp, xx -> xp0}, wp];
compactTotal = N[hCompactExpr /. {rrho -> rp, xx -> xp0}, wp];

p0DirectValue = N[p0DirectExpr /. {rrho -> rp, xx -> xp0}, wp];
p0DecomposedValue = N[p0DecomposedExpr /. {rrho -> rp, xx -> xp0}, wp];
angleValue = N[angleExpr /. {rrho -> rp, xx -> xp0}, wp];

origDerivative = N[dHdLambdaOriginalExpr /. {ee -> ep, xx -> xpD}, wp];
directDerivative = N[dHdLambdaDirectExpr /. {rrho -> rp, xx -> xpD}, wp];
sectorDerivative = N[dHdLambdaSectorExpr /. {rrho -> rp, xx -> xpD}, wp];

log["Diagnostic point: e=9/10, x=0"];
log["Original primary ArcTan term: " <> ToString[origPrimary, InputForm]];
log["Compact primary ArcTan term: " <> ToString[compactPrimary, InputForm]];
log["Original correction ArcTan term: " <> ToString[origCorrection, InputForm]];
log["Compact correction ArcTan term: " <> ToString[compactCorrection, InputForm]];
log["Original algebraic term: " <> ToString[origAlg, InputForm]];
log["Compact algebraic term: " <> ToString[compactAlg, InputForm]];
log["Original total H: " <> ToString[origTotal, InputForm]];
log["Compact total H: " <> ToString[compactTotal, InputForm]];
log["Compact angle: " <> ToString[angleValue, InputForm]];
log["P0 direct: " <> ToString[p0DirectValue, InputForm]];
log["P0 decomposed: " <> ToString[p0DecomposedValue, InputForm]];

log["Derivative point: e=9/10, x=1/2"];
log["Original dH/dlambda: " <> ToString[origDerivative, InputForm]];
log["Direct compact dH/dlambda: " <> ToString[directDerivative, InputForm]];
log["Sector compact dH/dlambda: " <> ToString[sectorDerivative, InputForm]];

primaryError = Abs[origPrimary - compactPrimary];
correctionError = Abs[origCorrection - compactCorrection];
algError = Abs[origAlg - compactAlg];
totalError = Abs[origTotal - compactTotal];
p0Error = Abs[p0DirectValue - p0DecomposedValue];
origDirectDerivativeError = Abs[origDerivative - directDerivative];
directSectorDerivativeError = Abs[directDerivative - sectorDerivative];

pass = TrueQ[
  primaryError < 10^-65 &&
  correctionError < 10^-65 &&
  algError < 10^-65 &&
  totalError < 10^-65 &&
  p0Error < 10^-65 &&
  origDirectDerivativeError < 10^-55 &&
  directSectorDerivativeError < 10^-55
];

summary = <|
  "MathematicaVersion" -> $Version,
  "PrimaryArcError" -> ToString[primaryError, InputForm],
  "CorrectionArcError" -> ToString[correctionError, InputForm],
  "AlgebraicError" -> ToString[algError, InputForm],
  "TotalHError" -> ToString[totalError, InputForm],
  "P0DecompositionError" -> ToString[p0Error, InputForm],
  "OriginalVsDirectDerivativeError" -> ToString[origDirectDerivativeError, InputForm],
  "DirectVsSectorDerivativeError" -> ToString[directSectorDerivativeError, InputForm],
  "Pass" -> pass,
  "Classification" -> If[pass,
    "V4_COMPONENT_DIAGNOSTIC_PASS",
    "V4_COMPONENT_DIAGNOSTIC_FAILED_DO_NOT_CONTINUE"
  ]
|>;

Export[
  FileNameJoin[{outputDirectory, "component_diagnostic_summary.json"}],
  summary,
  "RawJSON"
];
Put[summary, FileNameJoin[{outputDirectory, "component_diagnostic_summary.wl"}]];

log["Component diagnostic pass: " <> ToString[pass]];
log["PEABODY V4 COMPONENT DIAGNOSTIC: COMPLETE"];
Close[reportStream];
summary
