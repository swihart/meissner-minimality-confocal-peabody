(* ::Package:: *)

(*
  Run 01 v4: corrected compressed exponential-rapidity audit.

  Changes from v2:
    - the independent formula is split explicitly into ArcTan and algebraic
      sectors, with explicit multiplication signs;
    - all pointwise tests use high-precision approximate inputs before
      expression evaluation;
    - the compact derivative is checked in two independent forms:
        rho D[H,rho]  versus  P1 ArcTan + Q1;
    - the exact T-sector identity is reduced over Q(Sqrt[2]) rather than
      relying on Cancel alone.
*)

ClearAll["Global`*"];
$HistoryLength = 0;
$MaxExtraPrecision = 30000;

supportInputDir = Quiet@Check[
  If[StringQ[$InputFileName] && StringLength[$InputFileName] > 0,
    DirectoryName[ExpandFileName[$InputFileName]],
    Missing["Unavailable"]
  ],
  Missing["Unavailable"]
];
supportNotebookDir = Quiet@Check[
  If[$FrontEnd =!= Null, NotebookDirectory[], Missing["Unavailable"]],
  Missing["Unavailable"]
];
supportCandidates = DeleteDuplicates@Select[
  {supportInputDir, supportNotebookDir, Quiet@Check[Directory[], Missing["Unavailable"]]},
  StringQ[#] && DirectoryQ[#] &
];
supportPath = SelectFirst[
  supportCandidates,
  FileExistsQ[FileNameJoin[{#, "peabody_replay_support_v4.wl"}]] &,
  Missing["NotFound"]
];
If[MissingQ[supportPath],
  Print["FATAL: peabody_replay_support_v4.wl was not found."];
  Print["Candidate directories checked: ", supportCandidates];
  Abort[]
];
Get[FileNameJoin[{supportPath, "peabody_replay_support_v4.wl"}]];
baseDirectory = PeabodyV4ResolvePackageDirectory[];
corePath = PeabodyV4LoadCoreOrAbort[baseDirectory];

outputDirectory = FileNameJoin[{baseDirectory, "mathematica_output_compressed_audit_v4"}];
If[! DirectoryQ[outputDirectory],
  CreateDirectory[outputDirectory, CreateIntermediateDirectories -> True]
];

reportStream = OpenWrite[
  FileNameJoin[{outputDirectory, "compressed_audit_report.txt"}],
  PageWidth -> Infinity
];
ClearAll[log];
log[msg_] := Module[{s = ToString[msg, InputForm]},
  Print[msg];
  WriteString[reportStream, s, "\n"];
  Flush[reportStream]
];

log["PEABODY COMPRESSED RAPIDITY AUDIT V4: START"];
log["Mathematica version: " <> ToString[$Version]];
log["Core path: " <> corePath];
log["Output directory: " <> outputDirectory];

(* Independent formula, split into two explicit pieces. *)
ClearAll[
  ee, b2O, bO, aO, ampO, cO, uO, vO, yO,
  angleO, kernelO, outerO,
  hOriginalArcExpr, hOriginalAlgebraicExpr, hOriginalTotalExpr,
  dHdLambdaOriginalExpr
];

b2O = (3 + 4*Sqrt[2]*ee + 3*ee^2)/(1 - ee^2);
bO = Sqrt[b2O];
aO = bO/Sqrt[1 - ee^2];
ampO = Sqrt[1 - xx^2/b2O];
cO = ee*ampO;
uO = Sqrt[1 - 1/b2O];
vO = Sqrt[1 + 1/b2O];
yO = 1/(Sqrt[b2O + 1] + bO);
angleO = ArcTan[yO*Sqrt[(1 + cO)/(1 - cO)]];
kernelO = 4*angleO/Sqrt[1 - cO^2];
outerO = ee*(ampO - uO)/(1 - cO^2);

hOriginalArcPrimaryExpr = Times[-4, bO, Power[ampO, -1], kernelO, Power[aO, -1]];
hOriginalArcCorrectionExpr = Times[-4, bO, Power[ampO, -1], outerO, Plus[Times[vO, cO], -1], kernelO];
hOriginalArcExpr = Plus[hOriginalArcPrimaryExpr, hOriginalArcCorrectionExpr];
hOriginalAlgebraicExpr = Times[-4, bO, Power[ampO, -1], outerO, 2, Power[bO, -1]];
hOriginalTotalExpr = Plus[hOriginalArcExpr, hOriginalAlgebraicExpr];
dHdLambdaOriginalExpr = (1 - ee^2)*D[hOriginalTotalExpr, ee];

Put[hOriginalArcExpr,
  FileNameJoin[{outputDirectory, "original_arctan_sector.wl"}]
];
Put[hOriginalAlgebraicExpr,
  FileNameJoin[{outputDirectory, "original_algebraic_sector.wl"}]
];
Put[hCompactArcExpr,
  FileNameJoin[{outputDirectory, "compressed_arctan_sector.wl"}]
];
Put[hCompactAlgebraicExpr,
  FileNameJoin[{outputDirectory, "compressed_algebraic_sector.wl"}]
];
Put[dHdLambdaDirectExpr,
  FileNameJoin[{outputDirectory, "compressed_lambda_derivative_direct.wl"}]
];
Put[dHdLambdaSectorExpr,
  FileNameJoin[{outputDirectory, "compressed_lambda_derivative_sector.wl"}]
];

sizeRows = {
  {"expression", "LeafCount", "ByteCount"},
  {"H_compact", LeafCount[hCompactExpr], ByteCount[hCompactExpr]},
  {"H_compact_arc", LeafCount[hCompactArcExpr], ByteCount[hCompactArcExpr]},
  {"H_compact_alg", LeafCount[hCompactAlgebraicExpr], ByteCount[hCompactAlgebraicExpr]},
  {"dH_direct", LeafCount[dHdLambdaDirectExpr], ByteCount[dHdLambdaDirectExpr]},
  {"dH_sector", LeafCount[dHdLambdaSectorExpr], ByteCount[dHdLambdaSectorExpr]},
  {"H_original", LeafCount[hOriginalTotalExpr], ByteCount[hOriginalTotalExpr]},
  {"dH_original", LeafCount[dHdLambdaOriginalExpr], ByteCount[dHdLambdaOriginalExpr]}
};
Export[
  FileNameJoin[{outputDirectory, "compressed_expression_sizes.csv"}],
  sizeRows,
  "CSV"
];

wp = 90;
eGrid = {0, 1/1000, 1/10, 1/2, 9/10, 99/100, 999/1000};
xGrid = {0, 1/10, 1/2, 9/10, 1};

pointRows = Flatten[
  Table[
    Module[
      {ep, xp, rp, hoa, hca, hog, hcg, hot, hct, do, dd, ds},
      ep = N[eValue, wp];
      xp = N[xValue, wp];
      rp = N[rhoFromE[ep], wp];
      hoa = N[hOriginalArcExpr /. {ee -> ep, xx -> xp}, wp];
      hca = N[hCompactArcExpr /. {rrho -> rp, xx -> xp}, wp];
      hog = N[hOriginalAlgebraicExpr /. {ee -> ep, xx -> xp}, wp];
      hcg = N[hCompactAlgebraicExpr /. {rrho -> rp, xx -> xp}, wp];
      hot = hoa + hog;
      hct = hca + hcg;
      do = N[dHdLambdaOriginalExpr /. {ee -> ep, xx -> xp}, wp];
      dd = N[dHdLambdaDirectExpr /. {rrho -> rp, xx -> xp}, wp];
      ds = N[dHdLambdaSectorExpr /. {rrho -> rp, xx -> xp}, wp];
      {
        N[eValue, 25], N[rp, 35], N[xValue, 25],
        hoa, hca, Abs[hoa - hca],
        hog, hcg, Abs[hog - hcg],
        hot, hct, Abs[hot - hct],
        do, dd, ds, Abs[do - dd], Abs[dd - ds]
      }
    ],
    {eValue, eGrid}, {xValue, xGrid}
  ],
  1
];

pointHeader = {
  "e", "rho", "x",
  "H_arc_original", "H_arc_compact", "abs_arc_difference",
  "H_alg_original", "H_alg_compact", "abs_alg_difference",
  "H_total_original", "H_total_compact", "abs_total_difference",
  "dH_original", "dH_compact_direct", "dH_compact_sector",
  "abs_original_vs_direct_derivative",
  "abs_direct_vs_sector_derivative"
};
Export[
  FileNameJoin[{outputDirectory, "compressed_pointwise_audit.csv"}],
  Prepend[pointRows, pointHeader],
  "CSV"
];

maxArcError = Max[pointRows[[All, 6]]];
maxAlgError = Max[pointRows[[All, 9]]];
maxHError = Max[pointRows[[All, 12]]];
maxOriginalDerivativeError = Max[pointRows[[All, 16]]];
maxSectorDerivativeError = Max[pointRows[[All, 17]]];

log["Maximum ArcTan-sector H discrepancy: " <>
  ToString[N[maxArcError, 25], InputForm]];
log["Maximum algebraic-sector H discrepancy: " <>
  ToString[N[maxAlgError, 25], InputForm]];
log["Maximum total H discrepancy: " <>
  ToString[N[maxHError, 25], InputForm]];
log["Maximum original-versus-direct derivative discrepancy: " <>
  ToString[N[maxOriginalDerivativeError, 25], InputForm]];
log["Maximum direct-versus-sector derivative discrepancy: " <>
  ToString[N[maxSectorDerivativeError, 25], InputForm]];

ClearAll[nint];
nint[expr_] := NIntegrate[
  Evaluate[expr],
  {xx, 0, 1},
  WorkingPrecision -> wp,
  AccuracyGoal -> 38,
  PrecisionGoal -> 38,
  MinRecursion -> 2,
  MaxRecursion -> 30,
  Method -> {"GlobalAdaptive", "SymbolicProcessing" -> 0}
];

integralGrid = {0, 1/100, 1/10, 1/2, 9/10, 99/100};
integralRows = Table[
  Module[{ep, rp, po, pc},
    ep = N[eValue, wp];
    rp = N[rhoFromE[ep], wp];
    po = nint[N[hOriginalTotalExpr /. ee -> ep, wp]];
    pc = nint[N[hCompactExpr /. rrho -> rp, wp]];
    {N[eValue, 25], po, pc, Abs[po - pc]}
  ],
  {eValue, integralGrid}
];
Export[
  FileNameJoin[{outputDirectory, "compressed_integral_audit.csv"}],
  Prepend[integralRows,
    {"e", "Psi_original", "Psi_compact", "abs_difference"}],
  "CSV"
];
maxIntegralError = Max[integralRows[[All, 4]]];
log["Maximum integrated Psi discrepancy: " <>
  ToString[N[maxIntegralError, 25], InputForm]];

(* Exact rational-sector checks over Q(Sqrt[2]). *)
tSectorResidualRaw = Together[
  2*zz*D[uZExpr, zz]
  + (1 + ecoefExpr*zz/t2ZExpr)*uZExpr
  - pArcFZExpr
];
tSectorReducedNumerator =
  PeabodyV4ReduceSqrt2Numerator[tSectorResidualRaw];

tSectorDirectResidualRaw = Together[
  D[jTSectorExpr, xx]
  - Sqrt[t2ZExpr /. zz -> xx^2]*(pArcFZExpr /. zz -> xx^2)
];
tSectorDirectReducedNumerator =
  PeabodyV4ReduceSqrt2Numerator[tSectorDirectResidualRaw];

obstructionZ2At3 = FullSimplify[obstructionZ2Expr /. rrho -> 3];
obstructionZ1At3 = FullSimplify[obstructionZ1Expr /. rrho -> 3];

Put[tSectorResidualRaw,
  FileNameJoin[{outputDirectory, "t_sector_primitive_residual_raw.wl"}]
];
Put[tSectorReducedNumerator,
  FileNameJoin[{outputDirectory, "t_sector_primitive_reduced_numerator.wl"}]
];
Put[tSectorDirectReducedNumerator,
  FileNameJoin[{outputDirectory, "t_sector_direct_reduced_numerator.wl"}]
];

log["T-sector reduced rational-equation numerator: " <>
  ToString[tSectorReducedNumerator, InputForm]];
log["T-sector reduced direct-derivative numerator: " <>
  ToString[tSectorDirectReducedNumerator, InputForm]];
log["RT obstruction z^2 equation at rho=3: " <>
  ToString[obstructionZ2At3, InputForm]];
log["RT obstruction z^1 equation at rho=3: " <>
  ToString[obstructionZ1At3, InputForm]];

pass = TrueQ[
  maxArcError < 10^-60 &&
  maxAlgError < 10^-60 &&
  maxHError < 10^-60 &&
  maxOriginalDerivativeError < 10^-50 &&
  maxSectorDerivativeError < 10^-50 &&
  maxIntegralError < 10^-35 &&
  tSectorReducedNumerator === 0 &&
  tSectorDirectReducedNumerator === 0 &&
  obstructionZ2At3 =!= 0 &&
  obstructionZ1At3 =!= 0
];

summary = <|
  "MathematicaVersion" -> $Version,
  "WorkingPrecision" -> wp,
  "MaximumArcSectorDiscrepancy" -> ToString[maxArcError, InputForm],
  "MaximumAlgebraicSectorDiscrepancy" -> ToString[maxAlgError, InputForm],
  "MaximumTotalHDiscrepancy" -> ToString[maxHError, InputForm],
  "MaximumOriginalVsDirectDerivativeDiscrepancy" ->
    ToString[maxOriginalDerivativeError, InputForm],
  "MaximumDirectVsSectorDerivativeDiscrepancy" ->
    ToString[maxSectorDerivativeError, InputForm],
  "MaximumIntegratedPsiDiscrepancy" -> ToString[maxIntegralError, InputForm],
  "TSectorReducedNumerator" -> ToString[tSectorReducedNumerator, InputForm],
  "TSectorDirectReducedNumerator" ->
    ToString[tSectorDirectReducedNumerator, InputForm],
  "RTObstructionZ2AtRho3" -> ToString[obstructionZ2At3, InputForm],
  "RTObstructionZ1AtRho3" -> ToString[obstructionZ1At3, InputForm],
  "Pass" -> pass,
  "Classification" -> If[
    pass,
    "COMPRESSED_FORMULA_VALIDATED_LOW_COMPLEXITY_IBP_OBSTRUCTED",
    "COMPRESSED_AUDIT_V4_FAILED_DO_NOT_USE"
  ]
|>;

Put[summary,
  FileNameJoin[{outputDirectory, "compressed_audit_summary.wl"}]
];
Export[
  FileNameJoin[{outputDirectory, "compressed_audit_summary.json"}],
  summary,
  "RawJSON"
];

If[TrueQ[pass],
  Export[
    FileNameJoin[{outputDirectory, "RUN01_PASS.txt"}],
    "RUN01 V4 PASS\n",
    "Text"
  ]
];

log["Compressed audit pass: " <> ToString[pass]];
log["PEABODY COMPRESSED RAPIDITY AUDIT V4: COMPLETE"];
Close[reportStream];
summary
