(* ::Package:: *)

ClearAll[
  PeabodyV4ResolvePackageDirectory,
  PeabodyV4LoadCoreOrAbort,
  PeabodyV4RequireCoreOrAbort,
  PeabodyV4RequireRun01PassOrAbort,
  PeabodyV4SupportDirectory,
  PeabodyV4ReduceSqrt2Numerator
];

PeabodyV4SupportDirectory = Quiet@Check[
  If[StringQ[$InputFileName] && StringLength[$InputFileName] > 0,
    DirectoryName[ExpandFileName[$InputFileName]],
    Missing["Unavailable"]
  ],
  Missing["Unavailable"]
];

PeabodyV4ResolvePackageDirectory[] := Module[
  {inputDir, notebookDir, currentDir, supportDir, candidates, found},
  inputDir = Quiet@Check[
    If[StringQ[$InputFileName] && StringLength[$InputFileName] > 0,
      DirectoryName[ExpandFileName[$InputFileName]],
      Missing["Unavailable"]
    ],
    Missing["Unavailable"]
  ];
  notebookDir = Quiet@Check[
    If[$FrontEnd =!= Null, NotebookDirectory[], Missing["Unavailable"]],
    Missing["Unavailable"]
  ];
  currentDir = Quiet@Check[Directory[], Missing["Unavailable"]];
  supportDir = PeabodyV4SupportDirectory;
  candidates = DeleteDuplicates@Select[
    {supportDir, inputDir, notebookDir, currentDir},
    StringQ[#] && DirectoryQ[#] &
  ];
  found = SelectFirst[
    candidates,
    FileExistsQ[FileNameJoin[{#, "peabody_compressed_core_v4.wl"}]] &,
    Missing["NotFound"]
  ];
  If[MissingQ[found],
    Print["FATAL: peabody_compressed_core_v4.wl was not found."];
    Print["Candidate directories checked: ", candidates];
    Print["Keep every v4 .wl file in one extracted folder and use Get on the run file."];
    Abort[]
  ];
  found
];

PeabodyV4RequireCoreOrAbort[] := Module[{coreOK},
  coreOK = And[
    ValueQ[kappa],
    DownValues[rhoFromE] =!= {},
    ValueQ[p0Term1Expr],
    ValueQ[p0Term2Expr],
    ValueQ[hCompactExpr],
    ValueQ[p0DecomposedExpr],
    ValueQ[pArcTExpr],
    ValueQ[pArcRTExpr],
    ValueQ[dHdLambdaDirectExpr],
    ValueQ[dHdLambdaSectorExpr],
    ValueQ[uZExpr],
    ValueQ[obstructionZ2Expr],
    ValueQ[obstructionZ1Expr]
  ];
  If[! TrueQ[coreOK],
    Print["FATAL: the v4 Peabody core did not define all required symbols."];
    Abort[]
  ];
  If[
    Head[hCompactExpr] === Symbol || ByteCount[hCompactExpr] < 1000 ||
    Head[dHdLambdaSectorExpr] === Symbol || ByteCount[dHdLambdaSectorExpr] < 1000,
    Print["FATAL: the v4 Peabody core loaded incompletely."];
    Print["H ByteCount: ", ByteCount[hCompactExpr]];
    Print["dH/dlambda ByteCount: ", ByteCount[dHdLambdaSectorExpr]];
    Abort[]
  ];
  True
];

PeabodyV4LoadCoreOrAbort[dir_String] := Module[{corePath},
  corePath = FileNameJoin[{dir, "peabody_compressed_core_v4.wl"}];
  Print["Loading v4 core from: ", corePath];
  Get[corePath];
  PeabodyV4RequireCoreOrAbort[];
  Print[
    "V4 core preflight passed. H ByteCount = ", ByteCount[hCompactExpr],
    "; direct derivative ByteCount = ", ByteCount[dHdLambdaDirectExpr],
    "; sector derivative ByteCount = ", ByteCount[dHdLambdaSectorExpr], "."
  ];
  corePath
];

PeabodyV4RequireRun01PassOrAbort[dir_String] := Module[{gate},
  gate = FileNameJoin[{dir, "mathematica_output_compressed_audit_v4", "RUN01_PASS.txt"}];
  If[! FileExistsQ[gate],
    Print["FATAL: Run 01 v4 has not produced its PASS gate."];
    Print["Run 01 first and continue only if it prints 'Compressed audit pass: True'."];
    Abort[]
  ];
  gate
];

PeabodyV4ReduceSqrt2Numerator[expr_] := Module[
  {ss, rat, num, numS, remainder},
  rat = Together[expr];
  num = Expand[Numerator[rat]];
  numS = Expand[num /. Sqrt[2] -> ss];
  remainder = Last[PolynomialReduce[numS, {ss^2 - 2}, {ss}]];
  Expand[remainder]
];
