(* ::Package:: *)

(*
  Run 03 v4: prepare interval-certificate input expressions.

  Requires Run 01 PASS. This is a high-precision numerical conditioning audit,
  not an interval proof.
*)

ClearAll["Global`*"];
$HistoryLength = 0;
$MaxExtraPrecision = 30000;

supportInputDir = Quiet@Check[
  If[StringQ[$InputFileName] && StringLength[$InputFileName] > 0,
    DirectoryName[ExpandFileName[$InputFileName]],
    Missing["Unavailable"]
  ],
  Missing["Unavailable"]
];
supportNotebookDir = Quiet@Check[
  If[$FrontEnd =!= Null, NotebookDirectory[], Missing["Unavailable"]],
  Missing["Unavailable"]
];
supportCandidates = DeleteDuplicates@Select[
  {supportInputDir, supportNotebookDir, Quiet@Check[Directory[], Missing["Unavailable"]]},
  StringQ[#] && DirectoryQ[#] &
];
supportPath = SelectFirst[
  supportCandidates,
  FileExistsQ[FileNameJoin[{#, "peabody_replay_support_v4.wl"}]] &,
  Missing["NotFound"]
];
If[MissingQ[supportPath],
  Print["FATAL: peabody_replay_support_v4.wl was not found."];
  Abort[]
];
Get[FileNameJoin[{supportPath, "peabody_replay_support_v4.wl"}]];
baseDirectory = PeabodyV4ResolvePackageDirectory[];
corePath = PeabodyV4LoadCoreOrAbort[baseDirectory];
passGate = PeabodyV4RequireRun01PassOrAbort[baseDirectory];

outputDirectory = FileNameJoin[{baseDirectory, "mathematica_output_interval_inputs_v4"}];
If[! DirectoryQ[outputDirectory],
  CreateDirectory[outputDirectory, CreateIntermediateDirectories -> True]
];

reportStream = OpenWrite[
  FileNameJoin[{outputDirectory, "interval_input_report.txt"}],
  PageWidth -> Infinity
];
ClearAll[log];
log[msg_] := Module[{s = ToString[msg, InputForm]},
  Print[msg];
  WriteString[reportStream, s, "\n"];
  Flush[reportStream]
];

log["PEABODY INTERVAL INPUT PREPARATION V4: START"];
log["Mathematica version: " <> ToString[$Version]];
log["Core path: " <> corePath];
log["Run 01 gate: " <> passGate];

ClearAll[ee, qq];

(* dPhi/de = (dPhi/dlambda)/(1-e^2). *)
phiPrimeIntegrandEExpr =
  (dHdLambdaSectorExpr /. rrho -> rhoFromE[ee])/(8*(1 - ee^2));

(* q=(1-e)/(1+e), rho=kappa/Sqrt[q]. *)
tailScaledIntegrandQExpr =
  ((1 + qq)^3/(64*qq^2))*
    (dHdLambdaSectorExpr /. rrho -> kappa/Sqrt[qq]);

Put[phiPrimeIntegrandEExpr,
  FileNameJoin[{outputDirectory, "central_phi_prime_integrand_e.wl"}]
];
Put[tailScaledIntegrandQExpr,
  FileNameJoin[{outputDirectory, "tail_scaled_phi_prime_integrand_q.wl"}]
];

log["Central integrand ByteCount: " <>
  ToString[ByteCount[phiPrimeIntegrandEExpr]]];
log["Tail-scaled integrand ByteCount: " <>
  ToString[ByteCount[tailScaledIntegrandQExpr]]];

wp = 90;
ClearAll[nint];
nint[expr_] := NIntegrate[
  Evaluate[expr],
  {xx, 0, 1},
  WorkingPrecision -> wp,
  AccuracyGoal -> 38,
  PrecisionGoal -> 38,
  MinRecursion -> 3,
  MaxRecursion -> 35,
  Method -> {"GlobalAdaptive", "SymbolicProcessing" -> 0}
];

centralGrid = {0, 1/1000, 1/100, 1/10, 1/2, 9/10, 49/50, 199/200};
centralRows = Table[
  Module[{ep, value},
    ep = N[eValue, wp];
    value = nint[N[phiPrimeIntegrandEExpr /. ee -> ep, wp]];
    {N[eValue, 25], value}
  ],
  {eValue, centralGrid}
];
Export[
  FileNameJoin[{outputDirectory, "central_phi_prime_scout.csv"}],
  Prepend[centralRows, {"e", "PhiPrimeNumerical"}],
  "CSV"
];

tailGrid = {1/10, 1/100, 1/1000, 1/10000, 1/100000, 1/1000000};
tailRows = Table[
  Module[{qp, eValue, scaledValue},
    qp = N[qValue, wp];
    eValue = (1 - qp)/(1 + qp);
    scaledValue = nint[N[tailScaledIntegrandQExpr /. qq -> qp, wp]];
    {N[qValue, 25], N[eValue, 25], scaledValue}
  ],
  {qValue, tailGrid}
];
Export[
  FileNameJoin[{outputDirectory, "tail_scaled_derivative_scout.csv"}],
  Prepend[tailRows, {"q", "e", "PhiPrimeOverOneMinusE"}],
  "CSV"
];

numericCentralQ = VectorQ[centralRows[[All, 2]], NumericQ];
numericTailQ = VectorQ[tailRows[[All, 3]], NumericQ];
minCentral = If[numericCentralQ, Min[centralRows[[All, 2]]], Indeterminate];
minTailScaled = If[numericTailQ, Min[tailRows[[All, 3]]], Indeterminate];

log["Minimum central sampled Phi'(e): " <>
  ToString[N[minCentral, 25], InputForm]];
log["Minimum tail sampled Phi'(e)/(1-e): " <>
  ToString[N[minTailScaled, 25], InputForm]];

(* Frozen proof-campaign split. *)
eCut = 199/200;
qCut = FullSimplify[(1 - eCut)/(1 + eCut)];
plan = <|
  "CentralParameter" -> "e",
  "CentralRange" -> "0 <= e <= 199/200",
  "TailParameter" -> "q=(1-e)/(1+e)",
  "TailRange" -> ("0 < q <= " <> ToString[qCut, InputForm]),
  "TailScaledQuantity" -> "PhiPrime(e)/(1-e)",
  "MaximumTerminalBoxes" -> 5000,
  "MaximumCertificateBytes" -> 10000000,
  "Status" -> "INPUT_EXPRESSIONS_READY_NOT_CERTIFIED"
|>;
Export[
  FileNameJoin[{outputDirectory, "interval_certificate_plan.json"}],
  plan,
  "RawJSON"
];
Put[plan,
  FileNameJoin[{outputDirectory, "interval_certificate_plan.wl"}]
];

pass = TrueQ[
  numericCentralQ && numericTailQ &&
  minCentral > 0 && minTailScaled > 0
];
summary = <|
  "MathematicaVersion" -> $Version,
  "CentralValuesNumeric" -> numericCentralQ,
  "TailValuesNumeric" -> numericTailQ,
  "CentralScoutMinimum" -> ToString[minCentral, InputForm],
  "TailScaledScoutMinimum" -> ToString[minTailScaled, InputForm],
  "NumericalScoutPass" -> pass,
  "ProofStatus" -> "NOT_CERTIFIED",
  "Classification" -> If[
    pass,
    "INTERVAL_CERTIFICATE_INPUTS_READY",
    "INTERVAL_INPUT_SCOUT_V4_FAILED_DO_NOT_USE"
  ]
|>;
Export[
  FileNameJoin[{outputDirectory, "interval_input_summary.json"}],
  summary,
  "RawJSON"
];
Put[summary,
  FileNameJoin[{outputDirectory, "interval_input_summary.wl"}]
];

log["Numerical scout pass: " <> ToString[pass]];
log["PEABODY INTERVAL INPUT PREPARATION V4: COMPLETE"];
Close[reportStream];
summary
