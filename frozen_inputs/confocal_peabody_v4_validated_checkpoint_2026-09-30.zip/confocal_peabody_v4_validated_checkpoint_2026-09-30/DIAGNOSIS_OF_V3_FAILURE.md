# Diagnosis of the v3 component-diagnostic failure

The uploaded v3 report gave

- original primary ArcTan contribution: `-4.5392922575700793...`;
- original correction ArcTan contribution: `+0.3060211363330172...`;
- original total ArcTan sector: `-4.2332711212370621...`;
- compact ArcTan sector: `-4.5392922575700793...`.

Thus the compact formula retained exactly the primary ArcTan term and omitted
exactly the correction term.

The source of the omission was input-file parsing, not geometry. In v3 the
critical assignment was formatted as

```wl
p0DirectExpr =
  term1
  - term2;
```

The first physical line after `=` already completed an expression, so the next
line was read as a new expression rather than as part of the assignment. The
same defect affected the two-sector decomposition and two terms in the
lambda-derivative formula.

V4 replaces all such definitions with explicit `Plus[...]` and `Times[...]`
forms and adds separate primary/correction audit gates.
