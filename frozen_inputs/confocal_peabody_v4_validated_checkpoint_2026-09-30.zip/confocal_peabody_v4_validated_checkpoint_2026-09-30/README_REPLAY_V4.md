# Confocal Peabody compressed-symbolics replay v4

## Why v3 failed

The v3 mathematical formulas were written across multiple physical lines in a
way that is unsafe in a Wolfram Language input file.  A line such as

```wl
p0DirectExpr =
  term1
  + term2;
```

can assign only `term1`, because the assignment is already a complete
expression before the next line begins.  The v3 output proves exactly that:
the compact ArcTan sector retained its primary term but omitted its correction
term.  Several derivative definitions lost analogous continuation terms.

V4 uses explicit `Plus[...]` and `Times[...]` expressions for every critical
multi-term formula. It also logs the primary and correction terms separately.

## Run order

Use a fresh Mathematica kernel and `Get` the full path.

### Run 00 first

```wl
Get["/full/path/confocal_peabody_compressed_symbolics_replay_v4_2026-09-30/00_run_peabody_component_diagnostic_v4.wl"]
```

Required final line:

```text
Component diagnostic pass: True
```

Expected values at `e=9/10, x=0` include approximately:

```text
Original primary ArcTan term:   -4.5392922575700793...
Compact primary ArcTan term:    -4.5392922575700793...
Original correction ArcTan term: 0.3060211363330172...
Compact correction ArcTan term:  0.3060211363330172...
Original algebraic term:        -0.3437261999682297...
Compact algebraic term:         -0.3437261999682297...
```

Do not run 01-03 unless Run 00 passes.

### Run 01

```wl
Get["/full/path/confocal_peabody_compressed_symbolics_replay_v4_2026-09-30/01_run_peabody_compressed_audit_v4.wl"]
```

Required gate:

```text
Compressed audit pass: True
```

### Runs 02 and 03

Run only after Run 01 creates `mathematica_output_compressed_audit_v4/RUN01_PASS.txt`.

```wl
Get["/full/path/confocal_peabody_compressed_symbolics_replay_v4_2026-09-30/02_run_peabody_primitive_probe_v4.wl"]
Get["/full/path/confocal_peabody_compressed_symbolics_replay_v4_2026-09-30/03_prepare_peabody_interval_inputs_v4.wl"]
```
